import 'package:clincq_hospital/firebase_options.dart';
import 'package:clincq_hospital/providers/doctor_auth_provider.dart';
import 'package:clincq_hospital/providers/hospital_auth_provider.dart';
import 'package:clincq_hospital/screens/Doctor/appointments_screen.dart';
import 'package:clincq_hospital/screens/Doctor/doctor_login_screen.dart';
import 'package:clincq_hospital/screens/Hospital/Departments/department_screen.dart';
import 'package:clincq_hospital/screens/Hospital/Departments/doctor_appointment_screen.dart';
import 'package:clincq_hospital/screens/Hospital/Departments/doctor_details.dart';
import 'package:clincq_hospital/screens/Hospital/Departments/doctor_profile.dart';
import 'package:clincq_hospital/screens/Hospital/Doctors/doctor_profile.dart';
import 'package:clincq_hospital/screens/Hospital/hospital_login_screen.dart';
import 'package:clincq_hospital/screens/Hospital/hospital_sign_up_screen.dart';
import 'package:clincq_hospital/screens/homeScreen/home_screen.dart';
import 'package:clincq_hospital/screens/splashScreen/splash_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      systemStatusBarContrastEnforced: true,
      systemNavigationBarColor: Colors.transparent,
      systemNavigationBarDividerColor: Colors.transparent,
      systemNavigationBarIconBrightness: Brightness.dark,
      statusBarIconBrightness: Brightness.dark,
    ),
  );
  SystemChrome.setEnabledSystemUIMode(
    SystemUiMode.edgeToEdge,
    overlays: [SystemUiOverlay.top],
  );
}

final navigatorKey = GlobalKey<NavigatorState>();

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (context) => HospitalAuth(),
        ),
        ChangeNotifierProvider(
          create: (context) => DoctorAuth(),
        ),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        navigatorKey: navigatorKey,
        title: 'Clinicq',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepOrangeAccent),
          useMaterial3: true,
        ),
        home: const MySplashScreen(),
        // add routes
        routes: {
          HospitalSignUpScreen.routeName: (context) =>
              const HospitalSignUpScreen(),
          HospitalLoginScreen.routeName: (context) =>
              const HospitalLoginScreen(),
          DoctorLoginScreen.routeName: (context) => const DoctorLoginScreen(),
          AppointmentScreen.routeName: (context) => const AppointmentScreen(),
          DepartmentScreen.routeName: (context) => const DepartmentScreen(),
          DoctorProfile.routeName: (context) => const DoctorProfile(),
          DoctorProfileScreen.routeName: (context) =>
              const DoctorProfileScreen(),
          DoctorAppointmentScreen.routeName: (context) =>
              const DoctorAppointmentScreen(),
          DoctorDetails.routeName: (context) => const DoctorDetails(),
        },
      ),
    );
  }
}
