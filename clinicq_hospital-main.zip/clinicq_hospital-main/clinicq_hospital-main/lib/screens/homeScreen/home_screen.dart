import 'package:clincq_hospital/screens/Doctor/doctor_login_screen.dart';
import 'package:clincq_hospital/screens/Hospital/hospital_login_screen.dart';
import 'package:clincq_hospital/screens/Hospital/hospital_sign_up_screen.dart';
import 'package:flutter/material.dart';

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key});

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.primary,
        title: Row(
          mainAxisAlignment:
              MainAxisAlignment.center, // This will center the row contents
          children: [
            Image.asset('assets/logo.png', height: height * 0.06),
            const Text('ClinicsQueue',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold)),
          ],
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _header(context),
            SizedBox(
              height: height * 0.05,
            ),
            Image.asset('assets/hospital.png', height: height * 0.25),
            SizedBox(
              height: height * .05,
            ),
            ElevatedButton(
                style: ElevatedButton.styleFrom(
                  maximumSize: const Size(double.infinity * .02, 50),
                ),
                onPressed: () {
                  Navigator.of(context).popAndPushNamed(
                    HospitalSignUpScreen.routeName,
                  );
                },
                child: const Text(
                  'Sign up as a Hospital',
                  style: TextStyle(fontSize: 20),
                )),
            SizedBox(
              height: height * 0.03,
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                maximumSize: const Size(double.infinity * .02, 50),
              ),
              onPressed: () {
                Navigator.of(context).popAndPushNamed(
                  HospitalLoginScreen.routeName,
                );
              },
              child: const Text(
                'Login as a Hospital',
                style: TextStyle(fontSize: 20),
              ),
            ),
            SizedBox(
              height: height * 0.05,
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                maximumSize: const Size(double.infinity * .02, 50),
              ),
              onPressed: () {
                Navigator.of(context).popAndPushNamed(
                  DoctorLoginScreen.routeName,
                );
              },
              child: const Text('Login as a Doctor',
                  style: TextStyle(fontSize: 20)),
            ),
          ],
        ),
      ),
    );
  }
}

Widget _header(context) {
  final Color primaryColor = Theme.of(context).colorScheme.primary;
  return Column(
    children: [
      Text(
        'Welcome to ClinicQueue',
        style: TextStyle(
            fontSize: 30, fontWeight: FontWeight.bold, color: primaryColor),
      ),
      Text(
        'Join us to get the best medical services',
        style: TextStyle(fontSize: 16, color: primaryColor.withOpacity(0.8)),
      ),
    ],
  );
}
