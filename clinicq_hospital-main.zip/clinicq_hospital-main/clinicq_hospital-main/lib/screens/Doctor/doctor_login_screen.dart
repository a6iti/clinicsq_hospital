import 'package:clincq_hospital/screens/Doctor/doctor_login_form.dart';
import 'package:clincq_hospital/screens/Doctor/profile_check_page.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class DoctorLoginScreen extends StatefulWidget {
  const DoctorLoginScreen({super.key});
  static const routeName = '/doctor-login';
  @override
  State<DoctorLoginScreen> createState() => _DoctorLoginScreenState();
}

class _DoctorLoginScreenState extends State<DoctorLoginScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return const ProfileCheckPage();
          } else {
            return const DoctorLoginForm();
          }
        },
      ),
    );
  }
}
