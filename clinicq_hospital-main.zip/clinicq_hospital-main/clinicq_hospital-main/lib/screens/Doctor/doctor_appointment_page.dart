// ignore_for_file: avoid_print

import 'package:clincq_hospital/providers/doctor_auth_provider.dart';
import 'package:clincq_hospital/screens/Doctor/appointments_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class DoctorAppointmentPage extends StatefulWidget {
  const DoctorAppointmentPage({super.key});

  @override
  State<DoctorAppointmentPage> createState() => _DoctorAppointmentPageState();
}

class _DoctorAppointmentPageState extends State<DoctorAppointmentPage> {
  String _getDaySuffix(int day) {
    if (day >= 11 && day <= 13) {
      return 'th';
    }
    switch (day % 10) {
      case 1:
        return 'st';
      case 2:
        return 'nd';
      case 3:
        return 'rd';
      default:
        return 'th';
    }
  }

  String _formatTime(String time) {
    final parts = time.split(":");
    var hour = int.parse(parts[0]);

    // Determine AM/PM
    String period = 'AM';
    if (hour >= 12) {
      period = 'PM';
      if (hour > 12) hour -= 12;
    }

    // Format time
    return '$hour:${parts[1]} $period';
  }

  final user = FirebaseAuth.instance.currentUser!;
  Color primaryColor = Colors.blue;
  Color backgroundColor = Colors.white;
  String selectedMonth = 'January';
  late String doctorId;
  late Future<String> _fetchDoctorIdFuture;
  late DateTime selectedDate;

  @override
  void initState() {
    super.initState();
    selectedDate = DateTime.now();
    _fetchDoctorIdFuture = _fetchDoctorId();
  }

  Future<String> _fetchDoctorId() async {
    try {
      final doctorId = await Provider.of<DoctorAuth>(
        listen: false,
        context,
      ).fetchDoctorId(user.email!);
      return doctorId;
    } catch (e) {
      print("Error fetching doctor ID: $e");
      rethrow; // Rethrow the error to handle it in FutureBuilder
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String>(
      future: _fetchDoctorIdFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        } else if (snapshot.hasError) {
          return Scaffold(
            body: Center(
              child: Text("Error: ${snapshot.error}"),
            ),
          );
        } else {
          doctorId = snapshot.data!;
          return _buildAppointmentPage(doctorId);
        }
      },
    );
  }

  Widget _buildAppointmentPage(String doctorId) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          'Appointment Slots',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: const Color(0xffAD3306),
        // centerTitle: true,ß
      ),
      backgroundColor: const Color(0xffF7E6DA),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(
              left: 18,
              right: 18,
              top: 10,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Select Date: ',
                  style: TextStyle(
                    fontSize: 16,
                    color: Color(0xffAD3306),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(width: 20),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    color: Theme.of(context).primaryColor,
                  ),
                  child: TextButton.icon(
                    onPressed: () {
                      _selectDate(context);
                    },
                    icon: const Icon(
                      Icons.calendar_today,
                      color: Colors.white,
                      size: 13,
                    ),
                    label: Text(
                      '${DateFormat('E,').format(selectedDate)} ${DateFormat('d').format(selectedDate)}${_getDaySuffix(selectedDate.day)} ${DateFormat('MMM y').format(selectedDate)}',
                      style: const TextStyle(
                        fontSize: 13,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection('slots')
                  .where('doctorId', isEqualTo: doctorId)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }
                if (snapshot.hasData) {
                  var data = snapshot.data!.docs;
                  var slots = data.map((e) => e.data()).toList();
                  slots
                      .sort((a, b) => a['starttime'].compareTo(b['starttime']));

                  var filteredSlots = slots.where((slot) {
                    var slotDate = DateTime.parse(slot['date']);
                    return slotDate.year == selectedDate.year &&
                        slotDate.month == selectedDate.month &&
                        slotDate.day == selectedDate.day;
                  }).toList();

                  // If there are no appointments for the selected date
                  if (filteredSlots.isEmpty) {
                    return const Center(
                      child: Text(
                        'No appointments added yet.',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    );
                  }
                  return ListView.builder(
                    itemBuilder: (context, index) {
                      var slotDate = (DateTime.parse(slots[index]['date']));
                      if (slotDate.day != selectedDate.day ||
                          slotDate.month != selectedDate.month ||
                          slotDate.year != selectedDate.year) {
                        return const SizedBox.shrink();
                      }
                      return InkWell(
                        onTap: () {
                          Navigator.pushNamed(
                            context,
                            AppointmentScreen.routeName,
                            arguments: {
                              'appointments': slots[index]['appointments'],
                              'slotIndex': index,
                              'slotId': slots[index]['id'],
                              'doctorId': doctorId,
                              'maxPatient': slots[index]['maxpatient'],
                            },
                          );
                        },
                        child: Card(
                          elevation: 4,
                          margin: const EdgeInsets.symmetric(
                              vertical: 8, horizontal: 16),
                          child: ListTile(
                            title: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Max Patients: ${slots[index]['maxpatient']}',
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.orange,
                                  ),
                                ),
                                Row(
                                  children: [
                                    Text(
                                      'Timings: ${_formatTime(slots[index]['starttime'])}',
                                      style: const TextStyle(
                                        fontSize: 12,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                    Text(
                                      ' - ${_formatTime(slots[index]['endtime'])}',
                                      style: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            trailing: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: <Widget>[
                                InkWell(
                                  onTap: () {
                                    Navigator.pushNamed(
                                      context,
                                      AppointmentScreen.routeName,
                                      arguments: {
                                        'appointments': slots[index]
                                            ['appointments'],
                                        'slotIndex': index,
                                        'slotId': slots[index]['id'],
                                        'doctorId': doctorId,
                                        'maxPatient': slots[index]
                                            ['maxpatient'],
                                      },
                                    );
                                  },
                                  child: Container(
                                    padding: const EdgeInsets.all(8),
                                    decoration: BoxDecoration(
                                      color: Theme.of(context).primaryColor,
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: const Text(
                                      'See Queue',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                    itemCount: slots.length,
                  );
                } else {
                  return const Placeholder();
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2025),
      lastDate: DateTime(2030),
    );
    if (pickedDate != null && pickedDate != selectedDate) {
      setState(() {
        selectedDate = pickedDate;
      });
    }
  }
}
