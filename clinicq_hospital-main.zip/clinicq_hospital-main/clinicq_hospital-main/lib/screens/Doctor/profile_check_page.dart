import 'package:clincq_hospital/screens/Doctor/create_profile.dart';
import 'package:clincq_hospital/screens/Doctor/doctor_homepage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class ProfileCheckPage extends StatelessWidget {
  const ProfileCheckPage({super.key});

  static const String defaultImageUrl =
      "https://firebasestorage.googleapis.com/v0/b/clinicmain-ec340.appspot.com/o/profile_images%2F49wcRcdU6dMZk3UlO9DkCxq5yQI3?alt=media&token=bbfef945-f8f9-4775-b925-a9c094b46091";

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser!;
    return StreamBuilder(
      stream: FirebaseFirestore.instance
          .collection('doctors')
          .where('email', isEqualTo: user.email)
          .snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        } else if (snapshot.hasData) {
          var data = snapshot.data!.docs.map((e) => e.data()).toList();
          for (var i = 0; i < data.length; i++) {
            if (data[i]['profileAdded'] == false) {
              return const CreateProfile();
            }
          }

          // Safely retrieve the data with a default value if it's null
          final doctorName =
              data[0]['name'] ?? 'No Name'; // Provide a default name
          final profileImageUrl = data[0]['profileImageUrl'] ?? defaultImageUrl;
          // ''; // Default image URL can be empty or some placeholder

          // final doctorName = data[0]['name'];
          // final profileImageUrl = data[0]['profileImageUrl'];
          return DoctorHomepage(
              docName: doctorName, profileImageUrl: profileImageUrl);
        } else {
          return const Center(
            child: Text('Something went wrong'),
          );
        }
      },
    );
  }
}
