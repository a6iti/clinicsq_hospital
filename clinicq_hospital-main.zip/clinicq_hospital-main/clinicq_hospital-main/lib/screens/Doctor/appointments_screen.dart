// ignore_for_file: avoid_print

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AppointmentScreen extends StatefulWidget {
  const AppointmentScreen({super.key});

  static const routeName = '/appointment-screen';

  @override
  State<AppointmentScreen> createState() => _AppointmentScreenState();
}

class _AppointmentScreenState extends State<AppointmentScreen> {
  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    final slotId = args['slotId'];
    final maxPatient = args['maxPatient'];

    return Scaffold(
      backgroundColor: const Color(0xffF7E6DA),
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          'Appointments',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: const Color(0xffAD3306),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              StreamBuilder(
                stream: FirebaseFirestore.instance
                    .collection('appointments')
                    .where('slotId', isEqualTo: slotId)
                    .snapshots(),
                builder: (context, snapshot) {
                  var index = 1;
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  }
                  if (snapshot.hasData) {
                    var appointments =
                        snapshot.data?.docs.map((e) => e.data()).toList();
                    appointments?.sort(
                      (a, b) => a['appointmentCreated'].compareTo(
                        b['appointmentCreated'],
                      ),
                    );
                    if (appointments!.isEmpty) {
                      return const Center(
                        child: Text(
                          'No appointments yet',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      );
                    }
                    int doneCount = appointments
                        .where((appointment) =>
                            appointment['status'] == 'ACCEPTED')
                        .length;
                    int pendingCount = appointments
                        .where(
                            (appointment) => appointment['status'] == 'PENDING')
                        .length;
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Maximum Slots = $maxPatient',
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.red,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'Total Slots= ${appointments.length}',
                              style: const TextStyle(
                                fontSize: 12,
                                color: Colors.black,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            Text(
                              'Done Slots= $doneCount',
                              style: const TextStyle(
                                fontSize: 12,
                                color: Colors.green,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            Text(
                              'Pending Slots= $pendingCount',
                              style: const TextStyle(
                                fontSize: 12,
                                color: Colors.orange,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 20),
                        Table(
                          border: TableBorder.all(
                            color: Colors.white,
                            width: 1.5,
                            style: BorderStyle.solid,
                          ),
                          defaultVerticalAlignment:
                              TableCellVerticalAlignment.middle,
                          children: [
                            TableRow(
                              decoration:
                                  const BoxDecoration(color: Color(0xffAD3306)),
                              children: [
                                _buildTableHeader('SrNo.'),
                                _buildTableHeader('Patient Name'),
                                _buildTableHeader('Reason'),
                                _buildTableHeader('Arrival Status'),
                                _buildTableHeader('Fees Status'),
                              ],
                            ),
                            ...appointments.map(
                              (appointment) {
                                return TableRow(
                                  children: [
                                    TableCell(
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Center(
                                          child: Text(
                                            (index++).toString(),
                                            style: const TextStyle(
                                              fontSize: 14,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    TableCell(
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Center(
                                          child: SingleChildScrollView(
                                            scrollDirection: Axis.horizontal,
                                            child: Text(
                                              appointment['name'],
                                              maxLines: 1,
                                              style: const TextStyle(
                                                fontSize: 14,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    TableCell(
                                      child: InkWell(
                                        onTap: () {
                                          showDialog(
                                            context: context,
                                            builder: (context) => AlertDialog(
                                              title: const Text('Reason'),
                                              content:
                                                  Text(appointment['reason']),
                                              actions: [
                                                TextButton(
                                                  onPressed: () {
                                                    Navigator.of(context).pop();
                                                  },
                                                  child: const Text('Close'),
                                                ),
                                              ],
                                            ),
                                          );
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Center(
                                            child: SingleChildScrollView(
                                              scrollDirection: Axis.horizontal,
                                              child: Text(
                                                appointment['reason'],
                                                style: const TextStyle(
                                                  fontSize: 14,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    TableCell(
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Center(
                                          child: AppointmentAction(
                                            status: appointment['status'],
                                            appointmentId: appointment['id'],
                                            slotId: slotId,
                                            appointmentCreatedBy: appointment[
                                                'appointmentCreatedBy'],
                                          ),
                                        ),
                                      ),
                                    ),
                                    TableCell(
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Center(
                                          child: FeesAction(
                                            feesStatus: appointment['feesPaid'],
                                            appointmentId: appointment['id'],
                                            slotId: slotId,
                                            appointmentCreatedBy: appointment[
                                                'appointmentCreatedBy'],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                );
                              },
                            ),
                          ],
                        ),
                        // SizedBox(height: MediaQuery.of(context).size.height * 0.05),
                      ],
                    );
                  }
                  return const Center(
                    child: Text(
                      'No appointments',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTableHeader(String text) {
    return Container(
      padding: const EdgeInsets.all(8.0),
      alignment: Alignment.center,
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.w500,
          color: Colors.white,
        ),
      ),
    );
  }
}

class AppointmentAction extends StatefulWidget {
  const AppointmentAction({
    Key? key,
    required this.status,
    required this.appointmentId,
    required this.slotId,
    required this.appointmentCreatedBy,
  }) : super(key: key);

  final String? status;
  final String? appointmentId;
  final String? slotId;
  final String? appointmentCreatedBy;
  @override
  State<AppointmentAction> createState() => _AppointmentActionState();
}

class _AppointmentActionState extends State<AppointmentAction> {
  @override
  Widget build(BuildContext context) {
    return widget.status == "PENDING"
        ? Column(
            children: [
              IconButton(
                onPressed: () async {
                  // showDialog(
                  //   context: context,
                  //   barrierDismissible: false,
                  //   builder: (context) => const Center(
                  //     child: CircularProgressIndicator(),
                  //   ),
                  // );
                  try {
                    await FirebaseFirestore.instance
                        .collection('appointments')
                        .doc(widget.appointmentId)
                        .update({
                      'status': 'ACCEPTED',
                      'acceptanceTime': DateTime.now(),
                    });
                    // ignore: use_build_context_synchronously
                    // Navigator.of(context).pop();
                  } on Exception catch (e) {
                    print(e);
                    // ignore: use_build_context_synchronously
                    Navigator.of(context).pop();
                  }
                },
                icon: const Icon(
                  Icons.check,
                  color: Colors.green,
                ),
              ),
              IconButton(
                onPressed: () async {
                  try {
                    await FirebaseFirestore.instance
                        .collection('appointments')
                        .doc(widget.appointmentId)
                        .update({
                      'status': 'REJECTED',
                      'acceptanceTime': DateTime.now(),
                    });
                    await FirebaseFirestore.instance
                        .collection('users')
                        .doc(widget.appointmentCreatedBy)
                        .update(
                      {
                        'appointments':
                            FieldValue.arrayRemove([widget.appointmentId])
                      },
                    );
                  } on Exception catch (e) {
                    print(e);
                  }
                },
                icon: const Icon(
                  Icons.close,
                  color: Colors.red,
                ),
              ),
            ],
          )
        : widget.status == "ACCEPTED"
            ? const SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Text(
                  'DONE',
                  style: TextStyle(
                    color: Colors.green,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              )
            : const SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Text(
                  'REJECTED',
                  style: TextStyle(
                    color: Colors.red,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              );
  }
}

class FeesAction extends StatefulWidget {
  const FeesAction({
    Key? key,
    required this.feesStatus,
    required this.appointmentId,
    required this.slotId,
    required this.appointmentCreatedBy,
  }) : super(key: key);

  final bool feesStatus;
  final String? appointmentId;
  final String? slotId;
  final String? appointmentCreatedBy;
  @override
  State<FeesAction> createState() => _FeesActionState();
}

class _FeesActionState extends State<FeesAction> {
  @override
  Widget build(BuildContext context) {
    return !widget.feesStatus
        ? Column(
            children: [
              IconButton(
                onPressed: () async {
                  // showDialog(
                  //   context: context,
                  //   barrierDismissible: false,
                  //   builder: (context) => const Center(
                  //     child: CircularProgressIndicator(),
                  //   ),
                  // );
                  try {
                    await FirebaseFirestore.instance
                        .collection('appointments')
                        .doc(widget.appointmentId)
                        .update({
                      'feesPaid': true,
                    });
                    // ignore: use_build_context_synchronously
                    // Navigator.of(context).pop();
                  } on Exception catch (e) {
                    print(e);
                    // ignore: use_build_context_synchronously
                    Navigator.of(context).pop();
                  }
                },
                icon: const Icon(
                  Icons.check,
                  color: Colors.green,
                ),
              ),
            ],
          )
        : const Text(
            'PAID',
            style: TextStyle(
              color: Colors.green,
              fontWeight: FontWeight.w500,
            ),
          );
  }
}
