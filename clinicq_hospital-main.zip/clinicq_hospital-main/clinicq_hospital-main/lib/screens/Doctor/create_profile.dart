// ignore_for_file: use_build_context_synchronously, avoid_print
import 'dart:io';
import 'package:clincq_hospital/main.dart';
import 'package:clincq_hospital/providers/doctor_auth_provider.dart';
import 'package:clincq_hospital/screens/homeScreen/home_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import 'profile_check_page.dart';

class CreateProfile extends StatefulWidget {
  const CreateProfile({super.key});

  @override
  State<CreateProfile> createState() => _CreateProfileState();
}

class _CreateProfileState extends State<CreateProfile> {
  final user = FirebaseAuth.instance.currentUser!;
  String title = 'Dr.';
  String gender = 'Male';
  String governmentId = 'Aadhar Card';
  late String doctorId;
  late Future<String> _fetchDoctorIdFuture;
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _degreeController = TextEditingController();
  final TextEditingController _collegeController = TextEditingController();
  final TextEditingController _experienceController = TextEditingController();
  final TextEditingController _yearController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _firstTimeFeesController =
      TextEditingController();
  final TextEditingController _normalFeesController = TextEditingController();
  final TextEditingController _registrationNumberController =
      TextEditingController();
  final TextEditingController _registrationCouncilController =
      TextEditingController();
  final TextEditingController _registrationYearController =
      TextEditingController();
  final TextEditingController _governmentIdNumberController =
      TextEditingController();
  final TextEditingController _designationController = TextEditingController();
  final TextEditingController _bioController = TextEditingController();

  File? _imageFile; // To hold the selected image file

  // Method to pick an image from gallery
  Future<void> _pickImage() async {
    final pickedImage = await ImagePicker().pickImage(
      source: ImageSource.gallery,
    );
    if (pickedImage != null) {
      setState(() {
        _imageFile = File(pickedImage.path);
      });
    }
  }

  // Method to upload image to Firebase Storage
  Future<String?> _uploadImage() async {
    if (_imageFile == null) return null; // No image selected
    try {
      final storageRef = FirebaseStorage.instance
          .ref()
          .child('profile_images')
          .child(user.uid);
      await storageRef.putFile(_imageFile!);
      final imageUrl = await storageRef.getDownloadURL();
      return imageUrl;
    } catch (e) {
      print('Error uploading image: $e');
      return 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT-B-UIFkgsDHV_iXWpu0jKktVYiI6B8inRFg&usqp=CAU';
    }
  }

  @override
  void initState() {
    super.initState();
    _fetchDoctorIdFuture = _fetchDoctorId();
  }

  Future<String> _fetchDoctorId() async {
    try {
      final doctorId = await Provider.of<DoctorAuth>(
        listen: false,
        context,
      ).fetchDoctorId(user.email!);
      return doctorId;
    } catch (e) {
      print("Error fetching doctor ID: $e");
      rethrow; // Rethrow the error to handle it in FutureBuilder
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String>(
      future: _fetchDoctorIdFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        } else if (snapshot.hasError) {
          return Scaffold(
            body: Center(
              child: Text("Error: ${snapshot.error}"),
            ),
          );
        } else {
          doctorId = snapshot.data!;
          return _buildProfileScreen(doctorId);
        }
      },
    );
  }

  Widget _buildProfileScreen(String doctorId) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () async {
            await FirebaseAuth.instance.signOut();
            Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) =>MyHomePage(),
              ),
            );
          },
        ),
        backgroundColor: Theme.of(context).colorScheme.primary,
        title: const Text(
          'Create Profile',
          style: TextStyle(
            color: Colors.white,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // _sizedBox(context),
            // _header(),
            // _sizedBox(context),
            _imageFile != null
                ? CircleAvatar(
                    radius: 100,
                    backgroundImage: FileImage(_imageFile!),
                  )
                : Container(),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).colorScheme.primary,
              ),
              onPressed: _pickImage,
              child: const Text('Add Image',
                  style: TextStyle(color: Colors.white, fontSize: 16)),
            ),
            _sizedBox(context),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: title,
                  style: GoogleFonts.poppins(),
                  onChanged: (String? newValue) {
                    setState(() {
                      title = newValue!;
                    });
                  },
                  items: <String>['Dr.', 'Ms.', 'Mrs.', 'Mr.']
                      .map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(
                        value,
                        style: GoogleFonts.poppins(
                          color: Colors.black,
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
            _sizedBox(context),
            _textField(
              _nameController,
              'Name',
              context,
              icon: Icons.person,
            ),
            _sizedBox(context),
            _textField(
              _bioController,
              'Bio',
              context,
              icon: Icons.person,
            ),
            _sizedBox(context),
            _textField(
              _designationController,
              'Designation',
              context,
              icon: Icons.person,
            ),
            _sizedBox(context),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: gender,
                  style: GoogleFonts.poppins(),
                  onChanged: (String? newValue) {
                    setState(() {
                      gender = newValue!;
                    });
                  },
                  items: <String>['Male', 'Female', 'Others']
                      .map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(
                        value,
                        style: GoogleFonts.poppins(
                          color: Colors.black,
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
            _sizedBox(context),
            _textField(_degreeController, 'Degree', context,
                icon: Icons.school),
            _sizedBox(context),
            _textField(_collegeController, 'College', context,
                icon: Icons.school),
            _sizedBox(context),
            _textField(_experienceController, 'Experience', context,
                icon: Icons.work),
            _sizedBox(context),
            _textField(_yearController, 'Passout Year', context,
                icon: Icons.calendar_month),
            _sizedBox(context),
            _textField(_phoneController, 'Phone', context,
                icon: Icons.phone_android),
            _sizedBox(context),
            _textField(
                _registrationNumberController, 'Registration Number', context,
                icon: Icons.confirmation_number),
            _sizedBox(context),
            _textField(
                _registrationCouncilController, 'Registration Council', context,
                icon: Icons.confirmation_number),
            _sizedBox(context),
            _textField(
                _registrationYearController, 'Registration Year', context,
                icon: Icons.calendar_today),
            _sizedBox(context),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: governmentId,
                  style: GoogleFonts.poppins(),
                  onChanged: (String? newValue) {
                    setState(() {
                      governmentId = newValue!;
                    });
                  },
                  items: <String>[
                    'Aadhar Card',
                    'Passport',
                    'PAN Card',
                    'Driving License',
                    'Voter ID',
                    'Ration Card'
                        'Election Commission Card'
                  ].map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(
                        value,
                        style: GoogleFonts.poppins(
                          color: Colors.black,
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
            _sizedBox(context),
            _textField(
              _governmentIdNumberController,
              'Government ID Number',
              context,
              icon: Icons.abc_outlined,
            ),
            _sizedBox(context),
            _textField(
              _firstTimeFeesController,
              'First Time Fees',
              context,
              icon: Icons.abc_outlined,
              isNumeric: true,
            ),
            _sizedBox(context),
            _textField(
              _normalFeesController,
              'Normal Fees',
              context,
              icon: Icons.abc_outlined,
              isNumeric: true,
            ),
            _sizedBox(context),
            _signUpButton(context),
            SizedBox(
              height: MediaQuery.of(context).size.height * .05,
            ),
          ],
        ),
      ),
    );
  }

  Widget _sizedBox(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * .02,
    );
  }

  Widget _textField(
    TextEditingController controller,
    String labelText,
    BuildContext context, {
    bool obscure = false,
    IconData? icon,
    bool isNumeric = false,
  }) {
    return SizedBox(
      width: MediaQuery.of(context).size.width * .9,
      height: MediaQuery.of(context).size.height * .07,
      child: TextField(
        // if labeltext is 'year' then keyboard type is number

        keyboardType: labelText == 'Passout Year' ||
                labelText == 'Phone' ||
                labelText == 'First Time Fees' ||
                labelText == 'Normal Fees' ||
                labelText == 'Experience' ||
                labelText == 'Registration Year' ||
                labelText == 'Registration Council'
            ? TextInputType.number
            : TextInputType.text,
        controller: controller,
        style: GoogleFonts.poppins(),
        obscureText: obscure,
        inputFormatters: isNumeric
            ? <TextInputFormatter>[
                FilteringTextInputFormatter.digitsOnly,
              ]
            : null,
        decoration: InputDecoration(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          labelText: labelText,
          fillColor: Theme.of(context).colorScheme.primary.withOpacity(0.1),
          filled: true,
          prefixIcon: icon != null ? Icon(icon) : null,
        ),
      ),
    );
  }

  Widget _signUpButton(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        maximumSize: const Size(double.infinity * .02, 50),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      onPressed: () async {
        // Check if all fields have been filled
        if (_nameController.text.isEmpty ||
            gender.isEmpty ||
            _degreeController.text.isEmpty ||
            _collegeController.text.isEmpty ||
            _experienceController.text.isEmpty ||
            _yearController.text.isEmpty ||
            _phoneController.text.isEmpty ||
            _registrationNumberController.text.isEmpty ||
            _registrationCouncilController.text.isEmpty ||
            _registrationYearController.text.isEmpty ||
            governmentId.isEmpty ||
            _governmentIdNumberController.text.isEmpty ||
            _firstTimeFeesController.text.isEmpty ||
            _normalFeesController.text.isEmpty ||
            _designationController.text.isEmpty ||
            _bioController.text.isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'Please fill all the fields.',
              ),
            ),
          );
          return;
        }

        // Check if phone number is 10 digits
        if (_phoneController.text.length != 10) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'Phone number should be 10 digits.',
              ),
            ),
          );
          return;
        }
        if (_experienceController.text.length != 2 &&
            _experienceController.text.length != 1) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'Experience should be 1 or 2 digits.',
              ),
            ),
          );
          return;
        }
        if (_yearController.text.length != 4) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'Passout Year should be of 4 digits',
              ),
            ),
          );
          return;
        }
        // Check if image has been added
        // if (_imageFile == null) {
        //   ScaffoldMessenger.of(context).showSnackBar(
        //     const SnackBar(
        //       content: Text(
        //         'Please add a picture.',
        //       ),
        //     ),
        //   );
        //   return;
        // }
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (context) => const Center(
            child: CircularProgressIndicator(),
          ),
        );
        try {
          final imageUrl = await _uploadImage();
          await FirebaseFirestore.instance
              .collection('doctors')
              .doc(doctorId)
              .update({
            'title': title,
            'profileImageUrl': imageUrl == null
                ? 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT-B-UIFkgsDHV_iXWpu0jKktVYiI6B8inRFg&usqp=CAU'
                : imageUrl,
            'name': _nameController.text,
            'gender': gender,
            'degree': _degreeController.text,
            'college': _collegeController.text,
            'experience': _experienceController.text,
            'year': _yearController.text,
            'phone': _phoneController.text,
            'designation': _designationController.text,
            'bio': _bioController.text,
            'registrationNumber': _registrationNumberController.text,
            'registrationCouncil': _registrationCouncilController.text,
            'registrationYear': _registrationYearController.text,
            'governmentId': governmentId,
            'governmentIdNumber': _governmentIdNumberController.text,
            'profileAdded': true,
            'firstTimeFees': int.parse(_firstTimeFeesController.text),
            'normalFees': int.parse(_normalFeesController.text),
          });
        } catch (e) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                e.toString(),
              ),
            ),
          );
        }
         Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              ProfileCheckPage(),
                        ),
                      );
        // navigatorKey.currentState!.popUntil((route) => route.isFirst);
      },
      child: const Text('Create Profile',
          style: TextStyle(color: Colors.white, fontSize: 16)),
    );
  }
}