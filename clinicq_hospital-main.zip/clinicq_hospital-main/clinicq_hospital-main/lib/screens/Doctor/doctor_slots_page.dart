// ignore_for_file: avoid_print

import 'package:clincq_hospital/providers/doctor_auth_provider.dart';
import 'package:clincq_hospital/widgets/Doctor/add_slot.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

class DoctorSlotsPage extends StatefulWidget {
  const DoctorSlotsPage({Key? key}) : super(key: key);

  @override
  State<DoctorSlotsPage> createState() => _DoctorSlotsPageState();
}

class _DoctorSlotsPageState extends State<DoctorSlotsPage> {
  String _getDaySuffix(int day) {
    if (day >= 11 && day <= 13) {
      return 'th';
    }
    switch (day % 10) {
      case 1:
        return 'st';
      case 2:
        return 'nd';
      case 3:
        return 'rd';
      default:
        return 'th';
    }
  }

  String _formatTime(String time) {
    final parts = time.split(":");
    var hour = int.parse(parts[0]);

    // Determine AM/PM
    String period = 'AM';
    if (hour >= 12) {
      period = 'PM';
      if (hour > 12) hour -= 12;
    }

    // Format time
    return '$hour:${parts[1]} $period';
  }

  final user = FirebaseAuth.instance.currentUser!;
  Color primaryColor = Colors.blue;
  Color backgroundColor = Colors.white;
  late String doctorId;
  late Future<String> _fetchDoctorIdFuture;

  @override
  void initState() {
    super.initState();
    _fetchDoctorIdFuture = _fetchDoctorId();
  }

  Future<String> _fetchDoctorId() async {
    try {
      final doctorId = await Provider.of<DoctorAuth>(
        listen: false,
        context,
      ).fetchDoctorId(user.email!);
      return doctorId;
    } catch (e) {
      print("Error fetching doctor ID: $e");
      rethrow;
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String>(
      future: _fetchDoctorIdFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        } else if (snapshot.hasError) {
          return Scaffold(
            body: Center(
              child: Text("Error: ${snapshot.error}"),
            ),
          );
        } else {
          doctorId = snapshot.data!;
          return _buildSlotsPage(doctorId);
        }
      },
    );
  }

  DateTime selectedDate = DateTime.now();
  final TextEditingController _maxPatientsController = TextEditingController();

  Widget _buildSlotsPage(String doctorId) {
    // late DateTime selectedDate = DateTime.now();

    return Scaffold(
      appBar: AppBar(
        // change back icon color
        iconTheme: const IconThemeData(
          color: Colors.white,
        ),
        title: const Text(
          'Doctor Slots',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      backgroundColor: const Color(0xffF7E6DA),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(
              left: 18,
              right: 18,
              top: 10,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Select Date: ',
                  style: TextStyle(
                    fontSize: 16,
                    color: Color(0xffAD3306),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(width: 20),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    color: Theme.of(context).primaryColor,
                  ),
                  child: TextButton.icon(
                    onPressed: () {
                      _selectDate(context);
                    },
                    icon: const Icon(
                      Icons.calendar_today,
                      color: Colors.white,
                      size: 13,
                    ),
                    label: Text(
                      '${DateFormat('E,').format(selectedDate)} ${DateFormat('d').format(selectedDate)}${_getDaySuffix(selectedDate.day)} ${DateFormat('MMM y').format(selectedDate)}',
                      style: const TextStyle(
                        fontSize: 13,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection('slots')
                  .where('doctorId', isEqualTo: doctorId)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }
                if (snapshot.hasData) {
                  var data = snapshot.data!.docs;
                  var slots = data.map((e) => e.data()).toList();
                  slots
                      .sort((a, b) => a['starttime'].compareTo(b['starttime']));
                  return ListView.builder(
                    itemBuilder: (context, index) {
                      var slotDate = (DateTime.parse(slots[index]['date']));
                      if (slotDate.day != selectedDate.day ||
                          slotDate.month != selectedDate.month ||
                          slotDate.year != selectedDate.year) {
                        return const SizedBox.shrink();
                      }
                      return Card(
                        elevation: 4,
                        margin: const EdgeInsets.symmetric(
                            vertical: 8, horizontal: 16),
                        child: ListTile(
                          title: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Max Patients: ${slots[index]['maxpatient']}',
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.orange,
                                ),
                              ),
                              Row(
                                children: [
                                  Text(
                                    'Timings: ${_formatTime(slots[index]['starttime'])}',
                                    style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    ' - ${_formatTime(slots[index]['endtime'])}',
                                    style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              InkWell(
                                onTap: () {
                                  showDialog(
                                    context: context,
                                    builder: (context) {
                                      return AlertDialog(
                                        title: const Text('Edit Slot'),
                                        content: TextField(
                                          decoration: const InputDecoration(
                                            labelText: 'Max Patients',
                                          ),
                                          keyboardType: TextInputType.number,
                                          controller: _maxPatientsController,
                                        ),
                                        actions: <Widget>[
                                          TextButton(
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                            },
                                            child: const Text('Cancel'),
                                          ),
                                          TextButton(
                                            onPressed: () async {
                                              try {
                                                await FirebaseFirestore.instance
                                                    .collection('slots')
                                                    .doc(slots[index]['id'])
                                                    .update({
                                                  'maxpatient':
                                                      _maxPatientsController
                                                                  .text !=
                                                              ''
                                                          ? int.parse(
                                                              _maxPatientsController
                                                                  .text,
                                                            )
                                                          : slots[index]
                                                              ['maxpatient'],
                                                });
                                                // ignore: use_build_context_synchronously
                                                Navigator.of(context).pop();
                                              } on Exception catch (e) {
                                                print(e);
                                              }
                                            },
                                            child: const Text('Save'),
                                          ),
                                        ],
                                      );
                                    },
                                  );
                                },
                                child: Icon(
                                  Icons.edit,
                                  color: Theme.of(context).primaryColor,
                                  size: 28,
                                ),
                              ),
                              const SizedBox(width: 10),
                              InkWell(
                                onTap: () async {
                                  bool confirmDelete = await showDialog(
                                    context: context,
                                    builder: (BuildContext context) {
                                      return AlertDialog(
                                        title: const Text("Confirm Delete"),
                                        content: const Text(
                                            "Are you sure you want to delete this slot?"),
                                        actions: <Widget>[
                                          TextButton(
                                            onPressed: () =>
                                                Navigator.of(context)
                                                    .pop(false),
                                            child: const Text("Cancel"),
                                          ),
                                          TextButton(
                                            onPressed: () async {
                                              await FirebaseFirestore.instance
                                                  .collection('slots')
                                                  .doc(slots[index]['id'])
                                                  .delete();
                                              await FirebaseFirestore.instance
                                                  .collection('doctors')
                                                  .doc(doctorId)
                                                  .update({
                                                'slots': FieldValue.arrayRemove(
                                                    [slots[index]['id']])
                                              });
                                              // ignore: use_build_context_synchronously
                                              Navigator.of(context).pop(true);
                                            },
                                            child: const Text("Delete"),
                                          ),
                                        ],
                                      );
                                    },
                                  );
                                  if (confirmDelete == true) {
                                    await FirebaseFirestore.instance
                                        .collection('slots')
                                        .doc(user.email)
                                        .update({
                                      'slots':
                                          FieldValue.arrayRemove([slots[index]])
                                    });
                                  }
                                },
                                child: Icon(
                                  Icons.delete,
                                  color: Theme.of(context).primaryColor,
                                  size: 28,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                    itemCount: slots.length,
                  );
                } else {
                  return const Placeholder();
                }
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: Theme.of(context).primaryColor,
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) {
              return AddSlotDialog(
                doctorId: doctorId,
                selectedDate: selectedDate,
              );
            },
          );
        },
        label: const Text(
          'Add Session',
          style: TextStyle(
              color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
        ),
      ),
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );
    if (pickedDate != null && pickedDate != selectedDate) {
      setState(() {
        selectedDate = pickedDate;
      });
    }
  }
}
