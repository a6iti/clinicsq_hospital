// import 'package:clincq_hospital/screens/Doctor/doctor_login_form.dart';
// ignore_for_file: avoid_print, use_build_context_synchronously

import 'dart:io';

import 'package:clincq_hospital/providers/doctor_auth_provider.dart';
import 'package:clincq_hospital/screens/Doctor/doctor_login_screen.dart';
import 'package:clincq_hospital/screens/Hospital/profile_screen.dart';
import 'package:clincq_hospital/screens/homeScreen/home_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

class DoctorProfilePage extends StatefulWidget {
  const DoctorProfilePage({super.key});

  @override
  State<DoctorProfilePage> createState() => _DoctorProfilePageState();
}

class _DoctorProfilePageState extends State<DoctorProfilePage> {
  final user = FirebaseAuth.instance.currentUser!;
  late String doctorName;
  late String doctorId;
  late Future<String> _fetchDoctorIdFuture;
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _experienceController = TextEditingController();
  final TextEditingController _normalFeesController = TextEditingController();
  final TextEditingController _firstTimeFeesController =
      TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _bioController = TextEditingController();
  final TextEditingController _designationController = TextEditingController();
  @override
  void initState() {
    super.initState();
    _fetchDoctorIdFuture = _fetchDoctorId();
  }

  Future<String> _fetchDoctorId() async {
    try {
      final doctorId = await Provider.of<DoctorAuth>(
        listen: false,
        context,
      ).fetchDoctorId(user.email!);
      return doctorId;
    } catch (e) {
      print("Error fetching doctor ID: $e");
      rethrow; // Rethrow the error to handle it in FutureBuilder
    }
  }

  File? _imageFile; // To hold the selected image file

  // Method to pick an image from gallery
  Future<void> _pickImage() async {
    final pickedImage = await ImagePicker().pickImage(
      source: ImageSource.gallery,
    );
    if (pickedImage != null) {
      setState(() {
        _imageFile = File(pickedImage.path);
      });
    }
  }

  // Method to upload image to Firebase Storage
  Future<String?> _uploadImage() async {
    if (_imageFile == null) return null; // No image selected
    try {
      final storageRef = FirebaseStorage.instance
          .ref()
          .child('profile_images')
          .child(user.uid);
      await storageRef.putFile(_imageFile!);
      final imageUrl = await storageRef.getDownloadURL();
      return imageUrl;
    } catch (e) {
      print('Error uploading image: $e');
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    print(user.email);
    return FutureBuilder<String>(
      future: _fetchDoctorIdFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        } else if (snapshot.hasError) {
          return Scaffold(
            body: Center(
              child: Text("Error: ${snapshot.error}"),
            ),
          );
        } else {
          doctorId = snapshot.data!;
          return _buildProfilePage(doctorId);
        }
      },
    );
  }

  Widget _buildProfilePage(String doctorId) {
    print(doctorId);
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: Theme.of(context).primaryColor,
        title: const Text(
          'Profile',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('doctors')
            .doc(doctorId)
            .snapshots(),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.hasData) {
            doctorName = snapshot.data!['name'];
            return SingleChildScrollView(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Column(
                    children: [
                      CircleAvatar(
                        radius: 50,
                        backgroundImage: NetworkImage(
                          snapshot.data!['profileImageUrl'],
                        ),
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              // show if doctor is online or offline
                              // show if doctor is online or offline
                              Row(
                                children: [
                                  Text('Online status: ',
                                      style: TextStyle(
                                          fontSize: 18,
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold)),
                                  Switch(
                                      activeColor: const Color.fromARGB(
                                          255, 58, 130, 60),
                                      inactiveTrackColor: Colors.red,
                                      value: snapshot.data!['online'],
                                      onChanged: (value) async {
                                        await FirebaseFirestore.instance
                                            .collection('doctors')
                                            .doc(doctorId)
                                            .update({
                                          'online': value,
                                        });
                                      }),
                                ],
                              ),

                              ElevatedButton(
                                onPressed: () {
                                  showDialog(
                                    context: context,
                                    builder: (context) {
                                      return AlertDialog(
                                        title: const Text('Edit Profile'),
                                        actions: <Widget>[
                                          TextButton(
                                            child: const Text('Cancel'),
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                            },
                                          ),
                                          TextButton(
                                            child: const Text('Edit'),
                                            onPressed: () async {
                                              // if phoneNumberController is not 10 digits then show dialog box error
                                              if (_phoneController
                                                          .text.length !=
                                                      10 &&
                                                  _phoneController
                                                      .text.isNotEmpty) {
                                                showDialog(
                                                  context: context,
                                                  builder: (context) {
                                                    return AlertDialog(
                                                      title:
                                                          const Text('Error'),
                                                      content: const Text(
                                                          'Phone number should be 10 digits.'),
                                                      actions: <Widget>[
                                                        TextButton(
                                                          child:
                                                              const Text('OK'),
                                                          onPressed: () {
                                                            Navigator.of(
                                                                    context)
                                                                .pop();
                                                          },
                                                        ),
                                                      ],
                                                    );
                                                  },
                                                );
                                                return;
                                              }

                                              showDialog(
                                                context: context,
                                                builder: (context) {
                                                  return const Center(
                                                    child:
                                                        CircularProgressIndicator(),
                                                  );
                                                },
                                              );
                                              // If password is changed then changed password in firebase auth
                                              if (_passwordController.text !=
                                                  '') {
                                                try {
                                                  await user.updatePassword(
                                                      _passwordController.text);
                                                  await FirebaseFirestore
                                                      .instance
                                                      .collection('doctors')
                                                      .doc(doctorId)
                                                      .update({
                                                    'password':
                                                        _passwordController
                                                            .text,
                                                  });
                                                } catch (e) {
                                                  print(
                                                      'Error updating password: $e');
                                                  Navigator.pop(context);
                                                  showDialog(
                                                    context: context,
                                                    builder: (context) {
                                                      return AlertDialog(
                                                        title:
                                                            const Text('Error'),
                                                        content: const Text(
                                                            'Error updating password. Please try again.'),
                                                        actions: <Widget>[
                                                          TextButton(
                                                            child: const Text(
                                                                'OK'),
                                                            onPressed: () {
                                                              Navigator.of(
                                                                      context)
                                                                  .pop();
                                                            },
                                                          ),
                                                        ],
                                                      );
                                                    },
                                                  );
                                                  return;
                                                }
                                              }
                                              try {
                                                if (_imageFile != null) {
                                                  final imageUrl =
                                                      await _uploadImage();
                                                  print(imageUrl);
                                                  await FirebaseFirestore
                                                      .instance
                                                      .collection('doctors')
                                                      .doc(doctorId)
                                                      .update({
                                                    'profileImageUrl': imageUrl,
                                                    'name': _nameController
                                                                .text ==
                                                            ''
                                                        ? snapshot.data!['name']
                                                        : _nameController.text,
                                                    'phone': _phoneController
                                                                .text ==
                                                            ''
                                                        ? snapshot
                                                            .data!['phone']
                                                        : _phoneController.text,
                                                    'experience':
                                                        _experienceController
                                                                    .text ==
                                                                ''
                                                            ? snapshot.data![
                                                                'experience']
                                                            : _experienceController
                                                                .text,
                                                    'normalFees': double.parse(
                                                        _normalFeesController
                                                                    .text ==
                                                                ''
                                                            ? snapshot.data![
                                                                    'normalFees']
                                                                .toString()
                                                            : _normalFeesController
                                                                .text),
                                                    'firstTimeFees':
                                                        double.parse(
                                                      _firstTimeFeesController
                                                                  .text ==
                                                              ''
                                                          ? snapshot.data![
                                                                  'firstTimeFees']
                                                              .toString()
                                                          : _firstTimeFeesController
                                                              .text,
                                                    ),
                                                    'bio': _bioController
                                                                .text ==
                                                            ''
                                                        ? snapshot.data!['bio']
                                                        : _bioController.text,
                                                    'designation':
                                                        _designationController
                                                                    .text ==
                                                                ''
                                                            ? snapshot.data![
                                                                'designation']
                                                            : _designationController
                                                                .text,
                                                  });
                                                } else {
                                                  await FirebaseFirestore
                                                      .instance
                                                      .collection('doctors')
                                                      .doc(doctorId)
                                                      .update(
                                                    {
                                                      'name': _nameController
                                                                  .text ==
                                                              ''
                                                          ? snapshot
                                                              .data!['name']
                                                          : _nameController
                                                              .text,
                                                      'phone': _phoneController
                                                                  .text ==
                                                              ''
                                                          ? snapshot
                                                              .data!['phone']
                                                          : _phoneController
                                                              .text,
                                                      'experience':
                                                          _experienceController
                                                                      .text ==
                                                                  ''
                                                              ? snapshot.data![
                                                                  'experience']
                                                              : _experienceController
                                                                  .text,
                                                      'normalFees': double.parse(
                                                          _normalFeesController
                                                                      .text ==
                                                                  ''
                                                              ? snapshot.data![
                                                                      'normalFees']
                                                                  .toString()
                                                              : _normalFeesController
                                                                  .text),
                                                      'firstTimeFees':
                                                          double.parse(
                                                        _firstTimeFeesController
                                                                    .text ==
                                                                ''
                                                            ? snapshot.data![
                                                                    'firstTimeFees']
                                                                .toString()
                                                            : _firstTimeFeesController
                                                                .text,
                                                      ),
                                                      'bio': _bioController
                                                                  .text ==
                                                              ''
                                                          ? snapshot
                                                              .data!['bio']
                                                          : _bioController.text,
                                                      'designation':
                                                          _designationController
                                                                      .text ==
                                                                  ''
                                                              ? snapshot.data![
                                                                  'designation']
                                                              : _designationController
                                                                  .text,
                                                    },
                                                  );
                                                }

                                                Navigator.pop(context);
                                                Navigator.pop(context);
                                              } catch (e) {
                                                // print('Error updating user data: $e');
                                                Navigator.pop(context);
                                                rethrow;
                                              }
                                            },
                                          ),
                                        ],
                                        content: SingleChildScrollView(
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            mainAxisSize: MainAxisSize.min,
                                            children: [
                                              _imageFile != null
                                                  ? CircleAvatar(
                                                      radius: 100,
                                                      backgroundImage:
                                                          FileImage(
                                                              _imageFile!),
                                                    )
                                                  : Container(),
                                              ElevatedButton(
                                                onPressed: _pickImage,
                                                child: const Text(
                                                    'Change Profile Image'),
                                              ),
                                              TextField(
                                                decoration:
                                                    const InputDecoration(
                                                  labelText: 'Name',
                                                ),
                                                controller: _nameController,
                                              ),
                                              TextField(
                                                keyboardType:
                                                    TextInputType.phone,
                                                decoration:
                                                    const InputDecoration(
                                                  labelText: 'Phone',
                                                ),
                                                controller: _phoneController,
                                              ),
                                              TextField(
                                                decoration:
                                                    const InputDecoration(
                                                  labelText: 'Experience',
                                                ),
                                                controller:
                                                    _experienceController,
                                              ),
                                              TextField(
                                                decoration:
                                                    const InputDecoration(
                                                  labelText: 'Bio',
                                                ),
                                                controller: _bioController,
                                              ),
                                              TextField(
                                                decoration:
                                                    const InputDecoration(
                                                  labelText: 'Designation',
                                                ),
                                                controller:
                                                    _designationController,
                                              ),
                                              TextField(
                                                keyboardType:
                                                    TextInputType.number,
                                                decoration:
                                                    const InputDecoration(
                                                  labelText: 'Normal Fees',
                                                ),
                                                controller:
                                                    _normalFeesController,
                                              ),
                                              TextField(
                                                keyboardType:
                                                    TextInputType.number,
                                                decoration:
                                                    const InputDecoration(
                                                  labelText: 'First Time Fees',
                                                ),
                                                controller:
                                                    _firstTimeFeesController,
                                              ),
                                              TextField(
                                                decoration:
                                                    const InputDecoration(
                                                  labelText: 'Password',
                                                ),
                                                controller: _passwordController,
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    },
                                  );
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor:
                                      Theme.of(context).primaryColor,
                                ),
                                child: const Text(
                                  'Edit Profile',
                                  style: TextStyle(
                                      fontSize: 16, color: Colors.white),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  ProfileField(
                    title: 'Title',
                    value: snapshot.data!['title'],
                  ),
                  ProfileField(
                    title: 'Bio',
                    value: snapshot.data!['bio'],
                  ),
                  ProfileField(
                    title: 'Designation',
                    value: snapshot.data!['designation'],
                  ),
                  ProfileField(
                    title: 'Name',
                    value: snapshot.data!['name'],
                  ),
                  ProfileField(
                    title: 'Gender',
                    value: snapshot.data!['gender'],
                  ),
                  ProfileField(
                    title: 'Email',
                    value: user.email ?? '',
                  ),
                  ProfileField(
                    title: 'Department',
                    value: snapshot.data!['specialization'],
                  ),
                  ProfileField(
                    title: 'Phone',
                    value: snapshot.data!['phone'],
                  ),
                  ProfileField(
                    title: 'Normal Fees',
                    value: snapshot.data!['normalFees'].toString(),
                  ),
                  ProfileField(
                    title: 'First Time Fees',
                    value: snapshot.data!['firstTimeFees'].toString(),
                  ),
                  ProfileField(
                    title: 'College',
                    value: snapshot.data!['college'],
                  ),
                  ProfileField(
                    title: 'Degree',
                    value: snapshot.data!['degree'],
                  ),
                  ProfileField(
                    title: 'Passout Year',
                    value: snapshot.data!['year'],
                  ),
                  ProfileField(
                    title: 'Experience',
                    value: snapshot.data!['experience'],
                  ),
                  ProfileField(
                    title: 'Government Id',
                    value: snapshot.data!['governmentId'],
                  ),
                  ProfileField(
                    title: 'Governtment Id Number',
                    value: snapshot.data!['governmentIdNumber'],
                  ),
                  ProfileField(
                    title: 'Registration council',
                    value: snapshot.data!['registrationCouncil'],
                  ),
                  ProfileField(
                    title: 'Registration number',
                    value: snapshot.data!['registrationNumber'],
                  ),
                  ProfileField(
                    title: 'Registration year',
                    value: snapshot.data!['registrationYear'],
                  ),
                  ProfileField(
                    title: 'Password',
                    value: snapshot.data!['password'],
                  ),
                  ElevatedButton(
                    onPressed: () async {
                      showDialog(
                        context: context,
                        builder: (context) {
                          return const Center(
                            child: CircularProgressIndicator(),
                          );
                        },
                      );
                      try {
                        await FirebaseAuth.instance.signOut();
                        Navigator.pop(context);
                      } on Exception {
                        Navigator.pop(context);
                        rethrow;
                      }
                      // Navigator.of(context).pushReplacement(
                      //   MaterialPageRoute(
                      //     builder: (context) =>
                      //         const DoctorLoginScreen(), // Replace YourLoginScreen with your actual login screen widget
                      //   ),
                      // );

                      Navigator.of(context).pushReplacement(
                        MaterialPageRoute(
                          builder: (context) =>
                              const MyHomePage(), // Replace YourLoginScreen with your actual login screen widget
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Theme.of(context).primaryColor,
                    ),
                    child: const Text(
                      'Sign Out',
                      style: TextStyle(fontSize: 16, color: Colors.white),
                    ),
                  ),
                  const SizedBox(
                    height: 50,
                  ),
                ],
              ),
            );
          } else if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          } else {
            return const Center(
              child: Text('No data available for this user.'),
            );
          }
        },
      ),
    );
  }
}

class ProfileField extends StatelessWidget {
  final String title;
  final String value;

  const ProfileField({Key? key, required this.title, required this.value})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      elevation: 4,
      child: ListTile(
        title: Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        subtitle: Text(
          value,
          style: const TextStyle(fontSize: 14),
        ),
      ),
    );
  }
}
