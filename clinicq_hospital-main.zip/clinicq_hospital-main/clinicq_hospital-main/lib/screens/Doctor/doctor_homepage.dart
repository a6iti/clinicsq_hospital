import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:clincq_hospital/screens/Doctor/doctor_appointment_page.dart';
import 'package:clincq_hospital/screens/Doctor/doctor_profile_page.dart';
import 'package:clincq_hospital/screens/Doctor/doctor_slots_page.dart';

class DoctorHomepage extends StatefulWidget {
  final String docName;
  final String profileImageUrl; // Add profile image URL
  const DoctorHomepage(
      {super.key, required this.docName, required this.profileImageUrl});
  @override
  State<DoctorHomepage> createState() => _DoctorHomepageState();
}

class _DoctorHomepageState extends State<DoctorHomepage> {
  String docName = 'Dr. Name';

  static const List<Widget> _pages = <Widget>[
    DoctorAppointmentPage(),
    DoctorSlotsPage(),
    DoctorProfilePage(),
  ];

  static const List<String> _pageNames = <String>[
    'Appointments',
    'Edit Slots',
    'Profile',
  ];
  static const List<Icon> _pageIcons = <Icon>[
    Icon(Icons.calendar_today_rounded, color: Color(0xffAD3306), size: 40.0),
    Icon(Icons.edit, color: Color(0xffAD3306), size: 40.0),
    Icon(Icons.person_rounded, color: Color(0xffAD3306), size: 40.0),
  ];
  // static List<Image> images = <Image>[
  //   Image.asset('assets/img1.jpg', height: 40.0),
  //   Image.asset('assets/img2.jpg', height: 40.0),
  //   Image.asset('assets/img3.jpg', height: 40.0),
  // ];
  final CarouselController _caraoselController = CarouselController();
  int idx = 0;
  int _currentIndex = 0;

  static const List<String> images = [
    "assets/img1.jpg",
    "assets/img2.jpg",
    "assets/img3.jpg"
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7E6DA),
      appBar: AppBar(
        // change hamburger icon color here
        iconTheme: const IconThemeData(color: Colors.white),

        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Hi, ${widget.docName}',
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 21,
                  fontWeight: FontWeight.bold,
                )),
            Image.asset(
              'assets/logo.png',
              height: MediaQuery.of(context).size.height * .05,
              fit: BoxFit.cover,
            )
          ],
        ),
        backgroundColor: const Color(0xffAD3306),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            SizedBox(
              height: 250,
              child: DrawerHeader(
                decoration: const BoxDecoration(
                  color: Color(0xFFF7E6DA),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 10),
                    const SizedBox(height: 10),
                    Center(
                      child: CircleAvatar(
                        // Load image from Firebase Storage URL
                        backgroundImage: NetworkImage(widget.profileImageUrl),
                        radius: 50, // adjust the size as needed
                      ),
                    ),
                    const SizedBox(height: 10),
                    Center(
                      child: Text(
                        'Hi, ${widget.docName}',
                        style: const TextStyle(
                          color: Color(0xffAD3306),
                          fontSize: 21,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            for (int i = 0; i < _pages.length; i++)
              ListTile(
                leading: _pageIcons[i],
                title: Text(
                  _pageNames[i],
                  style: const TextStyle(
                    color: Color(0xffAD3306),
                  ),
                ),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => _pages[i]),
                  );
                },
              ),
          ],
        ),
      ),
      body: Padding(
        padding: EdgeInsets.only(
          top: MediaQuery.of(context).size.height * 0.00,
        ),
        child: Center(
          child: Column(
            children: [
              const SizedBox(
                height: 10,
              ),
              Stack(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 214, 213, 213),
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: const Color.fromARGB(255, 241, 239, 239)
                              .withOpacity(0.5),
                          spreadRadius: 2,
                          blurRadius: 5,
                          offset:
                              const Offset(0, 3), // changes position of shadow
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Container(
                          color: const Color(0xFFF7E6DA),
                          child: CarouselSlider(
                            items: images
                                .map((path) => Image.asset(
                                      path,
                                      fit: BoxFit.cover,
                                    ))
                                .toList(),
                            options: CarouselOptions(
                              height: 200,
                              viewportFraction: 1.0,
                              enlargeCenterPage: true,
                              autoPlay: true,
                              onPageChanged: (index, reason) {
                                setState(() {
                                  _currentIndex = index;
                                });
                              },
                            ),
                            carouselController: _caraoselController,
                          ),
                        ),
                        Container(
                          color: const Color(0xFFF7E6DA),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: images.map((path) {
                              int index = images.indexOf(path);
                              return Container(
                                width: 8.0,
                                height: 8.0,
                                margin: const EdgeInsets.symmetric(
                                    vertical: 10.0, horizontal: 2.0),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _currentIndex == index
                                      ? const Color(0xffAD3306)
                                      : Colors.grey,
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => _pages[0],
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      shape: const CircleBorder(),
                      padding: const EdgeInsets.all(0),
                    ),
                    child: CircleAvatar(
                      radius: 80,
                      backgroundColor: Colors.transparent,
                      // backgroundImage: AssetImage(images[0]),
                      child: Text(
                        _pageNames[0],
                        style: const TextStyle(color: Color(0xffAD3306)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 20),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => _pages[1],
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      shape: const CircleBorder(),
                      padding: const EdgeInsets.all(
                          0), // Ensure the button takes the size of the child
                    ),
                    child: CircleAvatar(
                      radius: 80,
                      backgroundColor: Colors.transparent,
                      // backgroundImage:
                      // AssetImage(images[1]), // Background image path
                      child: Text(
                        _pageNames[1],
                        style: const TextStyle(color: Color(0xffAD3306)),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => _pages[2],
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  shape: const CircleBorder(),
                  padding: const EdgeInsets.all(
                      0), // Ensure the button takes the size of the child
                ),
                child: CircleAvatar(
                  radius: 80,
                  backgroundColor: Colors.transparent,
                  // backgroundImage:
                  //     AssetImage(images[2]), // Background image path
                  child: Text(
                    _pageNames[2],
                    style: const TextStyle(
                      color: Color(0xffAD3306),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
