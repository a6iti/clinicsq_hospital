// ignore_for_file: use_build_context_synchronously

import 'dart:io';

import 'package:clincq_hospital/screens/Hospital/hospital_login_screen.dart';
import 'package:clincq_hospital/screens/homeScreen/home_screen.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:image_picker/image_picker.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController phoneNumberController = TextEditingController();
  final TextEditingController stateController = TextEditingController();
  final TextEditingController postalCodeController = TextEditingController();
  final TextEditingController streetAddressController = TextEditingController();
  final TextEditingController localityController = TextEditingController();
  final TextEditingController landmarkController = TextEditingController();
  File? _imageFile;
  Future<void> _pickImage() async {
    final pickedImage = await ImagePicker().pickImage(
      source: ImageSource.gallery,
    );
    if (pickedImage != null) {
      setState(() {
        _imageFile = File(pickedImage.path);
      });
    }
  }

  Future<String?> _uploadImage() async {
    if (_imageFile == null) return null; // No image selected
    try {
      final storageRef = FirebaseStorage.instance
          .ref()
          .child('profile_images')
          .child('${FirebaseAuth.instance.currentUser!.uid}.jpg');
      await storageRef.putFile(_imageFile!);
      final imageUrl = await storageRef.getDownloadURL();
      return imageUrl;
    } catch (e) {
      // Handle error
      // ignore: avoid_print
      print('Error uploading image: $e');
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser!;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Profile',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('hospitals')
            .where(
              'email',
              isEqualTo: user.email,
            )
            .snapshots(),
        builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
          if (snapshot.hasError) {
            return const Center(
              child: Text('Oops! Something went wrong.'),
            );
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
          if (snapshot.data == null || snapshot.data!.docs.isEmpty) {
            return const Center(
              child: Text('No data available for this user.'),
            );
          }

          final hospitalData =
              snapshot.data!.docs[0].data() as Map<String, dynamic>;

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                ElevatedButton(
                  onPressed: () {
                    showDialog(
                      context: context,
                      builder: (context) {
                        return AlertDialog(
                          title: const Text('Edit Profile'),
                          actions: <Widget>[
                            TextButton(
                              child: const Text('No'),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            ),
                            TextButton(
                              child: const Text('Edit'),
                              onPressed: () async {
                                // if phoneNumberController is not 10 digits long show error
                                if (phoneNumberController.text.length != 10 &&
                                    phoneNumberController.text.isNotEmpty) {
                                  //show dialog box
                                  showDialog(
                                    context: context,
                                    builder: (context) {
                                      return AlertDialog(
                                        title: const Text('Error'),
                                        content: const Text(
                                            'Phone number should be 10 digits long.'),
                                        actions: <Widget>[
                                          TextButton(
                                            child: const Text('OK'),
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                            },
                                          ),
                                        ],
                                      );
                                    },
                                  );
                                  return;
                                }
                                showDialog(
                                  context: context,
                                  builder: (context) {
                                    return const Center(
                                      child: CircularProgressIndicator(),
                                    );
                                  },
                                );
                                final imageUrl = await _uploadImage();
                                if (imageUrl != null) {
                                  // Update Firestore document with new image URL
                                  await FirebaseFirestore.instance
                                      .collection('hospitals')
                                      .doc(snapshot.data!.docs[0].id)
                                      .update({'upiUrl': imageUrl});
                                }
                                try {
                                  await FirebaseFirestore.instance
                                      .collection('hospitals')
                                      .doc(snapshot.data!.docs[0].id)
                                      .update(
                                    {
                                      'name': nameController.text == ''
                                          ? hospitalData['name']
                                          : nameController.text,
                                      'phoneNumber':
                                          phoneNumberController.text == ''
                                              ? hospitalData['phoneNumber']
                                              : phoneNumberController.text,
                                      'state': stateController.text == ''
                                          ? hospitalData['state']
                                          : stateController.text,
                                      'postalCode':
                                          postalCodeController.text == ''
                                              ? hospitalData['postalCode']
                                              : postalCodeController.text,
                                      'streetAddress':
                                          streetAddressController.text == ''
                                              ? hospitalData['streetAddress']
                                              : streetAddressController.text,
                                      'locality': localityController.text == ''
                                          ? hospitalData['locality']
                                          : localityController.text,
                                      'landmark': landmarkController.text == ''
                                          ? hospitalData['landmark']
                                          : landmarkController.text,
                                    },
                                  );
                                  Navigator.pop(context);
                                  Navigator.pop(context);
                                } catch (e) {
                                  // print('Error updating user data: $e');
                                  Navigator.pop(context);
                                  rethrow;
                                }
                              },
                            ),
                          ],
                          content: SingleChildScrollView(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                TextFormField(
                                  decoration: const InputDecoration(
                                    labelText: 'Name',
                                  ),
                                  controller: nameController,
                                ),
                                TextFormField(
                                  keyboardType: TextInputType.phone,
                                  decoration: const InputDecoration(
                                    labelText: 'Phone Number',
                                  ),
                                  controller: phoneNumberController,
                                ),
                                TextFormField(
                                  decoration: const InputDecoration(
                                    labelText: 'State',
                                  ),
                                  controller: stateController,
                                ),
                                TextFormField(
                                  keyboardType: TextInputType.number,
                                  decoration: const InputDecoration(
                                    labelText: 'Pin Code',
                                  ),
                                  controller: postalCodeController,
                                ),
                                TextFormField(
                                  decoration: const InputDecoration(
                                    labelText: 'Address',
                                  ),
                                  controller: streetAddressController,
                                ),
                                TextFormField(
                                  decoration: const InputDecoration(
                                    labelText: 'Locality',
                                  ),
                                  controller: localityController,
                                ),
                                TextFormField(
                                  decoration: const InputDecoration(
                                    labelText: 'Landmark',
                                  ),
                                  controller: landmarkController,
                                ),
                                const SizedBox(height: 10),
                                ElevatedButton(
                                  onPressed: _pickImage,
                                  child: const Text('Edit Logo'),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).primaryColor,
                  ),
                  child: const Text(
                    'Edit Profile',
                    style: TextStyle(fontSize: 16, color: Colors.white),
                  ),
                ),
                ProfileField(title: 'Name', value: hospitalData['name'] ?? ''),
                ProfileField(
                    title: 'Email', value: hospitalData['email'] ?? ''),
                ProfileField(
                    title: 'Phone Number',
                    value: hospitalData['phoneNumber'] ?? ''),
                ProfileField(title: 'City', value: hospitalData['city'] ?? ''),
                ProfileField(
                    title: 'State', value: hospitalData['state'] ?? ''),
                ProfileField(
                    title: 'Pin Code', value: hospitalData['postalCode'] ?? ''),
                ProfileField(
                    title: 'Address',
                    value: hospitalData['streetAddress'] ?? ''),
                ProfileField(
                  title: 'Locality',
                  value: hospitalData['locality'] ?? '',
                ),
                ProfileField(
                  title: 'Landmark',
                  value: hospitalData['landmark'] ?? '',
                ),
                const SizedBox(
                  height: 20,
                ),
                Container(
                  padding: const EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20.0),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.5),
                        spreadRadius: 3,
                        blurRadius: 7,
                        offset:
                            const Offset(0, 3), // changes position of shadow
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        'Hospital Logo',
                        style: TextStyle(
                          fontFamily: 'Roboto',
                          fontSize: 18.0,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 10),
                      InkWell(
                        onTap: () {
                          showDialog(
                            context: context,
                            builder: (context) {
                              return AlertDialog(
                                title: const Text('Hospital Logo'),
                                content: SizedBox(
                                  width: 400,
                                  height: 400,
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(20.0),
                                    child: Image(
                                      width: 200,
                                      height: 200,
                                      image: NetworkImage(
                                        hospitalData['upiUrl'],
                                      ),
                                      fit: BoxFit.contain,
                                    ),
                                  ),
                                ),
                              );
                            },
                          );
                        },
                        child: SizedBox(
                          width: 200,
                          height: 200,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20.0),
                            child: Image(
                              width: 200,
                              height: 200,
                              image: NetworkImage(
                                hospitalData['upiUrl'],
                              ),
                              fit: BoxFit.contain,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    FirebaseAuth.instance.signOut();
                    // Navigator.of(context).pushReplacement(
                    //   MaterialPageRoute(
                    //     builder: (context) =>
                    //         const HospitalLoginScreen(), // Replace YourLoginScreen with your actual login screen widget
                    //   ),
                    // );
                    Navigator.of(context).pushReplacement(
                      MaterialPageRoute(
                        builder: (context) =>
                            const MyHomePage(), // Replace YourLoginScreen with your actual login screen widget
                      ),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Theme.of(context).primaryColor,
                  ),
                  child: const Text(
                    'Sign Out',
                    style: TextStyle(fontSize: 16, color: Colors.white),
                  ),
                ),
                const SizedBox(height: 50),
              ],
            ),
          );
        },
      ),
    );
  }
}

class ProfileField extends StatelessWidget {
  final String title;
  final String value;

  const ProfileField({super.key, required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      elevation: 4,
      child: ListTile(
        title: Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        subtitle: Text(
          value,
          style: const TextStyle(fontSize: 14),
        ),
      ),
    );
  }
}
