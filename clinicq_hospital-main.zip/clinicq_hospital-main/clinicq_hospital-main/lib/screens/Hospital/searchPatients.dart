import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class SearchPatientsPage extends StatefulWidget {
  final String hospitalName;

  const SearchPatientsPage({required this.hospitalName});

  @override
  _SearchPatientsPageState createState() => _SearchPatientsPageState();
}

class _SearchPatientsPageState extends State<SearchPatientsPage> {
  late Stream<QuerySnapshot> _appointmentsStream;
  TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _appointmentsStream = FirebaseFirestore.instance
        .collection('appointments')
        .where('hospitalName', isEqualTo: widget.hospitalName)
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Search Patients',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: Column(
        children: [
          SizedBox(height: 10),
          Padding(
            padding: EdgeInsets.symmetric(
              horizontal: 20,
            ),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Search by Patient Name',
                prefixIcon: Icon(Icons.search, color: Colors.grey),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: Icon(Icons.clear, color: Colors.grey),
                        onPressed: () {
                          _searchController.clear();
                          setState(() {});
                        },
                      )
                    : null,
                filled: true,
                fillColor: Colors.white,
                contentPadding:
                    EdgeInsets.symmetric(vertical: 15.0, horizontal: 20.0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(25.0),
                  borderSide: BorderSide.none,
                ),
              ),
              onChanged: (value) {
                setState(() {});
              },
            ),
          ),
          SizedBox(height: 10),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: _appointmentsStream,
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  var filteredAppointments = snapshot.data!.docs.where((doc) {
                    String patientName = doc['name'].toString().toLowerCase();
                    String searchTerm = _searchController.text.toLowerCase();
                    return patientName.contains(searchTerm);
                  }).toList();

                  return ListView.builder(
                    itemCount: filteredAppointments.length,
                    itemBuilder: (context, index) {
                      var appointment = filteredAppointments[index];
                      // sort appointments in descending order of appointmentCreated
                      filteredAppointments.sort((a, b) {
                        return b['appointmentCreated']
                            .compareTo(a['appointmentCreated']);
                      });
                      return InkWell(
                        onTap: () {
                          showDialog(
                            context: context,
                            builder: (context) {
                              return AlertDialog(
                                title: Text('Appointment Details'),
                                content: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    appointmentDetailText(
                                      'Patient',
                                      appointment['name'],
                                    ),
                                    appointmentDetailText(
                                      'Doctor',
                                      appointment['doctorName'],
                                    ),
                                    appointmentDetailText(
                                      'Status',
                                      appointment['status'],
                                    ),
                                    if (appointment['status'] == 'ACCEPTED')
                                      appointmentDetailText(
                                        'Accepted',
                                        getFormattedDate(
                                          appointment['acceptanceTime']
                                              .toDate()),
                                      ),
                                    appointmentDetailText(
                                      'Created',
                                      getFormattedDate(
                                          appointment['appointmentCreated']
                                              .toDate()),
                                    ),
                                    appointmentDetailText(
                                      'Phone',
                                      appointment['phone'],
                                    ),
                                    appointmentDetailText(
                                      'Reason',
                                      appointment['reason'],
                                    ),
                                    appointmentDetailText(
                                      'Fees Paid',
                                      appointment['feesPaid'].toString(),
                                    ),
                                  ],
                                ),
                                actions: [
                                  TextButton(
                                    onPressed: () {
                                      Navigator.pop(context);
                                    },
                                    child: Text('Close'),
                                  ),
                                ],
                              );
                            },
                          );
                        },
                        child: Card(
                          child: ListTile(
                            title: Text(appointment['name']),
                            subtitle: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Doctor: ' + appointment['doctorName']),
                                if (appointment['status'] == 'ACCEPTED')
                                  Text('Accepted: ' +
                                      getFormattedDate(
                                          appointment['acceptanceTime']
                                              .toDate())),
                                Text('Created: ' +
                                    getFormattedDate(
                                        appointment['appointmentCreated']
                                            .toDate())),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  );
                } else if (snapshot.hasError) {
                  return Center(
                    child: Text('Error: ${snapshot.error}'),
                  );
                } else {
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                }
              },
            ),
          ),
          // SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget appointmentDetailText(String title, String value) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          Text(value),
        ],
      ),
    );
  }

  //create a function take date time and return string in english format
  String getFormattedDate(DateTime dateTime) {
    // Format date in English format (dd MMM yyyy)
    DateFormat dateFormatter = DateFormat('dd MMM yyyy', 'en_US');
    String formattedDate = dateFormatter.format(dateTime);

    // Format time in AM/PM format
    DateFormat timeFormatter = DateFormat('h:mm a');
    String formattedTime = timeFormatter.format(dateTime);

    return '$formattedDate, $formattedTime';
  }
}
