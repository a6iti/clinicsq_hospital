import 'package:clincq_hospital/screens/Hospital/hospital_sign_up_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class HospitalLoginForm extends StatefulWidget {
  const HospitalLoginForm({super.key});

  @override
  State<HospitalLoginForm> createState() => _HospitalLoginFormState();
}

class _HospitalLoginFormState extends State<HospitalLoginForm> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool _obscureText = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        margin: const EdgeInsets.all(24),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 40),
              Image.asset('assets/logo.png', height: 150),
              const SizedBox(height: 20),
              _header(),
              const SizedBox(height: 40),
              _inputField(context),
              const SizedBox(height: 20),
              _signup(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _header() {
    return const Column(
      children: [
        Text(
          'Welcome Back',
          style: TextStyle(fontSize: 40, fontWeight: FontWeight.bold),
        ),
        Text(
          'Enter your hospital credentials to login',
          style: TextStyle(fontSize: 16),
        ),
      ],
    );
  }

  Widget _inputField(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TextField(
          controller: _emailController,
          decoration: InputDecoration(
            labelText: 'Email',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(18),
              borderSide: BorderSide.none,
            ),
            fillColor: Theme.of(context).colorScheme.primary.withOpacity(0.1),
            filled: true,
            prefixIcon: const Icon(Icons.email),
          ),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _passwordController,
          decoration: InputDecoration(
            labelText: 'Password',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(18),
              borderSide: BorderSide.none,
            ),
            fillColor: Theme.of(context).colorScheme.primary.withOpacity(0.1),
            filled: true,
            prefixIcon: const Icon(Icons.password),
            suffixIcon: IconButton(
              icon: Icon(
                _obscureText ? Icons.visibility : Icons.visibility_off,
              ),
              onPressed: () {
                setState(() {
                  _obscureText = !_obscureText;
                });
              },
            ),
          ),
          obscureText: _obscureText,
        ),
        const SizedBox(height: 10),
        ElevatedButton(
          style: ElevatedButton.styleFrom(
            shape: const StadiumBorder(),
            padding: const EdgeInsets.symmetric(vertical: 16),
            backgroundColor: Theme.of(context).colorScheme.primary,
          ),
          onPressed: _handleLogin,
          child: const Text(
            'Login as a Hospital',
            style: TextStyle(fontSize: 20, color: Colors.white),
          ),
        ),
      ],
    );
  }

  Future<void> _handleLogin() async {
    // Show loading dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: CircularProgressIndicator(),
      ),
    );

    try {
      // Check if the email exists in the 'hospitals' collection
      final emailCheck = await FirebaseFirestore.instance
          .collection('hospitals')
          .where('email', isEqualTo: _emailController.text.trim())
          .get();

      if (emailCheck.docs.isEmpty) {
        if (mounted) {
          _dismissDialog();
          _showSnackBar('Email not found');
        }
        return;
      }

      // Try to sign in with the provided credentials
      await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );

      // Ensure the dialog is dismissed only if the widget is still mounted
      if (mounted) {
        _dismissDialog();
        _showSnackBar('Login successful');
      }
    } on FirebaseAuthException catch (e) {
      if (mounted) {
        _dismissDialog();
        _showSnackBar(e.message ?? 'An error occurred');
      }
    }
  }

  void _dismissDialog() {
    if (mounted && Navigator.of(context).canPop()) {
      Navigator.of(context).pop(); // Close the dialog
    }
  }

  void _showSnackBar(String message) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message)),
      );
    }
  }

  Widget _signup(BuildContext context) {
    final Color primaryColor = Theme.of(context).colorScheme.primary;

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text("Don't have an account? "),
        TextButton(
          onPressed: () {
            Navigator.of(context).popAndPushNamed(
              HospitalSignUpScreen.routeName,
            );
          },
          child: Text(
            "Sign Up",
            style: TextStyle(color: primaryColor),
          ),
        ),
      ],
    );
  }
}
