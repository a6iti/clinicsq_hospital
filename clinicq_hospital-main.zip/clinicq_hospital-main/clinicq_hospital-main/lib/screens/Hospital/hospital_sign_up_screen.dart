import 'package:clincq_hospital/screens/Hospital/hospital_homepage.dart';
import 'package:clincq_hospital/screens/Hospital/hospital_signup_form.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class HospitalSignUpScreen extends StatefulWidget {
  const HospitalSignUpScreen({super.key});
  static const routeName = '/hospital-signup';
  @override
  State<HospitalSignUpScreen> createState() => _HospitalSignUpScreenState();
}

class _HospitalSignUpScreenState extends State<HospitalSignUpScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return const HospitalHomepage();
          } else {
            return const HospitalSignUpForm();
          }
        },
      ),
    );
  }
}
