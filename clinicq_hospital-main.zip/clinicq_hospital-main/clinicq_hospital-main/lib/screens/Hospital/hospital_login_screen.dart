import 'package:clincq_hospital/screens/Hospital/hospital_homepage.dart';
import 'package:clincq_hospital/screens/Hospital/hospital_login_form.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class HospitalLoginScreen extends StatefulWidget {
  static const routeName = '/hospital-login';
  const HospitalLoginScreen({super.key});

  @override
  State<HospitalLoginScreen> createState() => _HospitalLoginScreenState();
}

class _HospitalLoginScreenState extends State<HospitalLoginScreen> {
  final user = FirebaseAuth.instance.currentUser;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder(
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return const HospitalHomepage();
          } else {
            return const HospitalLoginForm();
          }
        },
      ),
    );
  }
}
