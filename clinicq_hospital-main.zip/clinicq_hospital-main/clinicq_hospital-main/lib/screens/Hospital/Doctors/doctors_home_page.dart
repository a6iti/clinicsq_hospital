// ignore_for_file: avoid_print

import 'package:clincq_hospital/providers/hospital_auth_provider.dart';
import 'package:clincq_hospital/screens/Hospital/Departments/doctor_profile.dart';
import 'package:clincq_hospital/widgets/Hospital/add_doctor_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class DoctorsHomePage extends StatefulWidget {
  const DoctorsHomePage({super.key});

  @override
  State<DoctorsHomePage> createState() => _DoctorHomePageState();
}

class _DoctorHomePageState extends State<DoctorsHomePage> {
  String? selectedDepartment;
  List<Map<String, dynamic>> departmentListFinal = [];
  bool isLoading = true;
  late String hospitalId;
  late Map<String, String> hospitalDetails;
  late Future<String> _fetchHospitalIdFuture;

  @override
  void initState() {
    super.initState();
    _fetchHospitalIdFuture = _fetchHospitalId();

    // fetchDepartments();
  }

  Future<Map<String, String>> _fetchHospitalDetails(String hospitalId) async {
    try {
      final hospitalSnapshot = await FirebaseFirestore.instance
          .collection('hospitals')
          .doc(hospitalId)
          .get();
      final hospitalData = hospitalSnapshot.data();
      if (hospitalData != null) {
        final String hospitalName = hospitalData['name'] ?? '';
        final String logo = hospitalData['upiUrl'] ?? '';
        final String locality = hospitalData['locality'] ?? '';
        final String address = hospitalData['streetAddress'] ?? '';
        final String city = hospitalData['city'] ?? '';
        final String state = hospitalData['state'] ?? '';
        final String pincode = hospitalData['postalCode'] ?? '';
        final String phone1 = hospitalData['phoneNumber'] ?? '';
        final String phone2 = hospitalData['phoneTwo'] ?? '';
        final String email = hospitalData['email'] ?? '';
        // final String logo = hospitalData['upiUrl'] ?? '';
        print(hospitalName);
        return {
          'id': hospitalId,
          'name': hospitalName,
          'upiUrl': logo,
          'locality': locality,
          'streetAddress': address,
          'city': city,
          'state': state,
          'postalCode': pincode,
          'phoneNumber': phone1,
          'phoneTwo': phone2,
          'email': email,
          'upiUrl': logo,
        };
      } else {
        throw Exception('Hospital data not found');
      }
    } catch (e) {
      print("Error fetching hospital details: $e");
      rethrow;
    }
  }

  Future<String> _fetchHospitalId() async {
    try {
      final hospitalId = await Provider.of<HospitalAuth>(
        context,
        listen: false,
      ).fetchHospitalId(user.email!);
      final departmentsSnapshots = FirebaseFirestore.instance
          .collection('departments')
          .where('hospitalId', isEqualTo: hospitalId)
          .get();
      final departmentsData = await departmentsSnapshots;
      for (var element in departmentsData.docs) {
        var data = element.data();
        var name = data['name'];
        if (name != null) {
          departmentListFinal.add(data);
        }
      }

      print(departmentListFinal);
      final fetchedHospitalDetails = await _fetchHospitalDetails(hospitalId);
      hospitalDetails =
          fetchedHospitalDetails; // Assign fetched details to class-level variable
      return hospitalId;
    } catch (e) {
      print("Error fetching hospital ID: $e");
      rethrow; // Rethrow the error to handle it in FutureBuilder
    }
  }

  final user = FirebaseAuth.instance.currentUser!;
  // String qrLink = '';

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String>(
      future: _fetchHospitalIdFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        } else if (snapshot.hasError) {
          return Scaffold(
            body: Center(
              child: Text("Error: ${snapshot.error}"),
            ),
          );
        } else {
          return _buildDoctorScreen(snapshot.data!);
        }
      },
    );
  }

  String searchQuery = '';
  Widget _buildDoctorScreen(String hospitalId) {
    List<dynamic> getFilteredDoctors(List<dynamic> doctorArray) {
      if (searchQuery.isNotEmpty) {
        return doctorArray.where((doctor) {
          String name = doctor['name'].toString().toLowerCase();
          String specialization =
              doctor['specialization'].toString().toLowerCase();
          String query = searchQuery.toLowerCase();

          return name.contains(query) || specialization.contains(query);
        }).toList();
      } else {
        return doctorArray;
      }
    }

    //fetch data from firebase collection 'qr' and id 1
   
    print(hospitalId);
    print(hospitalDetails);

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Doctors',
          style: TextStyle(
            color: Color(0xffAD3306),
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: const Color(0xffF7E6DA),
      ),
      backgroundColor: const Color(0xffF7E6DA),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: Theme.of(context).primaryColor,
        label: const Text(
          'Add Doctor',
          style: TextStyle(
              color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
        ),
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) {
              return AddDoctorDialog(
                departmentList: departmentListFinal,
                hospitalId: hospitalId,
                hospitalDetails: hospitalDetails,
              );
            },
          );
        },
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              onChanged: (value) {
                // print(value);
                setState(() {
                  searchQuery = value;
                });
              },
              decoration: const InputDecoration(
                focusColor: Color(0xffAD3306),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  borderSide: BorderSide(width: 10),
                ),
                contentPadding:
                    EdgeInsets.symmetric(vertical: 10, horizontal: 8),
                hintText: 'Search for doctors...',
                prefixIcon: Icon(
                  Icons.search,
                  color: Color(0xffAD3306),
                ),
                filled: false, // enable fill color
              ),
            ),
            const SizedBox(
              height: 16,
            ),
            Expanded(
              child: StreamBuilder(
                stream: FirebaseFirestore.instance
                    .collection('doctors')
                    .where('hospitalId', isEqualTo: hospitalId)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  } else if (!snapshot.hasData) {
                    return const Center(
                      child: Text('No doctors added yet.'),
                    );
                  } else {
                    var data = snapshot.data!.docs;
                    var doctors = data.map((e) => e.data()).toList();
                    return ListView.builder(
                      itemCount: getFilteredDoctors(doctors).length,
                      itemBuilder: (context, index) {
                        List<dynamic> sortedDoctors = getFilteredDoctors(
                            doctors)
                          ..sort((a, b) => (a['name'] as String)
                              .toLowerCase()
                              .compareTo((b['name'] as String).toLowerCase()));
                        return InkWell(
                          onTap: () {
                            Navigator.pushNamed(
                              context,
                              DoctorProfile.routeName,
                              arguments: {
                                'doctorId': sortedDoctors[index]['id'],
                                'name': sortedDoctors[index]['name'],
                                'hospitalDetails': hospitalDetails,
                                'designation': sortedDoctors[index]
                                    ['designation'],
                                'registrationNumber': sortedDoctors[index]
                                    ['registrationNumber'],
                                'phone': sortedDoctors[index]['phone'],
                              },
                            );
                          },
                          child: Card(
                            elevation: 4,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15.0),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Row(
                                children: [
                                  CircleAvatar(
                                    radius: 35,
                                    backgroundColor: Theme.of(context)
                                        .primaryColor
                                        .withOpacity(0.7),
                                    backgroundImage: getFilteredDoctors(
                                                    doctors)[index]
                                                ['profileImageUrl'] !=
                                            null
                                        ? NetworkImage(
                                            getFilteredDoctors(doctors)[index]
                                                ['profileImageUrl'])
                                        : null,
                                    child: getFilteredDoctors(doctors)[index]
                                                ['profileImageUrl'] ==
                                            null
                                        ? const Icon(
                                            Icons.person,
                                            color: Colors.white,
                                          )
                                        : null,
                                  ),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          sortedDoctors[index]['name']
                                              as String,
                                          style: const TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          sortedDoctors[index]['specialization']
                                              as String,
                                          style: const TextStyle(
                                            fontSize: 12,
                                            color: Colors.grey,
                                          ),
                                        ),
                                        const SizedBox(
                                            height: 8), // Adjusted spacing
                                        Row(
                                          children: [
                                            const Text(
                                              'Online Status:',
                                              style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            const SizedBox(
                                                width: 4), // Adjusted spacing
                                            Switch(
                                              inactiveTrackColor: Colors.red,
                                              activeColor: const Color.fromARGB(
                                                  255, 41, 113, 43),
                                              value: sortedDoctors[index]
                                                  ['online'] as bool,
                                              onChanged: (bool value) {
                                                FirebaseFirestore.instance
                                                    .collection('doctors')
                                                    .doc(sortedDoctors[index]
                                                        ['id'])
                                                    .update({'online': value});
                                              },
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  IconButton(
                                    onPressed: () {
                                      showDialog(
                                        context: context,
                                        builder: (BuildContext context) {
                                          return AlertDialog(
                                            title:
                                                const Text('Confirm Deletion'),
                                            content: const Text(
                                                'Are you sure you want to delete this doctor?'),
                                            actions: <Widget>[
                                              TextButton(
                                                onPressed: () {
                                                  Navigator.of(context)
                                                      .pop(); // Close the dialog
                                                },
                                                child: const Text('Cancel'),
                                              ),
                                              TextButton(
                                                onPressed: () {
                                                  _deleteDoctor(
                                                      sortedDoctors[index]);
                                                  Navigator.of(context)
                                                      .pop(); // Close the dialog
                                                },
                                                child: const Text(
                                                  'Delete',
                                                  style: TextStyle(
                                                      color: Colors.red),
                                                ),
                                              ),
                                            ],
                                          );
                                        },
                                      );
                                    },
                                    icon: const Icon(
                                      Icons.delete,
                                      color: Colors.red,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  }
                },
              ),
            ),
            SizedBox(height: MediaQuery.of(context).size.height * 0.07),
          ],
        ),
      ),
    );
  }

  void _deleteDoctor(Map<String, dynamic> doctor) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: CircularProgressIndicator(),
      ),
    );
    // create one collection to store deleted doctors
    await FirebaseFirestore.instance
        .collection('deletedDoctors')
        .doc(doctor['id'])
        .set(doctor);

    await FirebaseFirestore.instance
        .collection('departments')
        .doc(doctor['specialixationId'])
        .update({
      'doctors': FieldValue.arrayRemove([doctor['id']]),
    });
    FirebaseFirestore.instance
        .collection('doctors')
        .doc(doctor['id'])
        .delete()
        .then((_) {
      Navigator.of(context).pop(); // Close the loading dialog
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Doctor deleted successfully.'),
        ),
      );
    }).catchError(
      (error) {
        Navigator.of(context).pop(); // Close the loading dialog
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to delete doctor: $error'),
          ),
        );
      },
    );
  }
}
