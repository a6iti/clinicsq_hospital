import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class DoctorProfileScreen extends StatefulWidget {
  const DoctorProfileScreen({super.key});
  static const routeName = '/doctor-profile-screen';

  @override
  State<DoctorProfileScreen> createState() => _DoctorProfileState();
}

class _DoctorProfileState extends State<DoctorProfileScreen> {
  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    final doctorEmail = args['email'];
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection('doctorProfile')
              .doc(doctorEmail)
              .snapshots(),
          builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
            if (snapshot.hasData) {
              final data = snapshot.data!.data() as Map<String, dynamic>?;

              return ListView(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  ProfileField(
                    title: 'title',
                    value: data?['title'] ?? '',
                  ),
                  ProfileField(
                    title: 'name',
                    value: data?['name'] ?? '',
                  ),
                  ProfileField(
                    title: 'gender',
                    value: data?['gender'] ?? '',
                  ),
                  ProfileField(
                    title: 'email',
                    value: doctorEmail ?? '',
                  ),
                  ProfileField(
                    title: 'year',
                    value: data?['year'] ?? '',
                  ),
                  ProfileField(
                    title: 'department',
                    value: data?['department'] ?? '',
                  ),
                  ProfileField(
                    title: 'phone',
                    value: data?['phone'] ?? '',
                  ),
                  ProfileField(
                    title: 'college',
                    value: data?['college'] ?? '',
                  ),
                  ProfileField(
                    title: 'degree',
                    value: data?['degree'] ?? '',
                  ),
                  ProfileField(
                    title: 'experience',
                    value: data?['experience'] ?? '',
                  ),
                  ProfileField(
                    title: 'government Id',
                    value: data?['governmentId'] ?? '',
                  ),
                  ProfileField(
                    title: 'government Id Number',
                    value: data?['governmentIdNumber'] ?? '',
                  ),
                  ProfileField(
                    title: 'registration council',
                    value: data?['registrationCouncil'] ?? '',
                  ),
                  ProfileField(
                    title: 'registration number',
                    value: data?['registrationNumber'] ?? '',
                  ),
                  ProfileField(
                    title: 'registration year',
                    value: data?['registrationYear'] ?? '',
                  ),
                ],
              );
            } else if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            } else {
              return const Center(
                child: Text('Doctor details not available'),
              );
            }
          },
        ),
      ),
    );
  }
}

class ProfileField extends StatelessWidget {
  final String title;
  final String value;

  const ProfileField({super.key, required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      elevation: 4,
      child: ListTile(
        title: Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        subtitle: Text(
          value,
          style: const TextStyle(fontSize: 14),
        ),
      ),
    );
  }
}
