import 'package:clincq_hospital/screens/Hospital/Departments/doctor_details.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class DepartmentScreen extends StatefulWidget {
  const DepartmentScreen({super.key});
  static const routeName = '/department';
  @override
  State<DepartmentScreen> createState() => _DepartmentScreenState();
}

class _DepartmentScreenState extends State<DepartmentScreen> {
  final user = FirebaseAuth.instance.currentUser!;
  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    final department = args['department'];
    final departmentId = args['departmentId'];
    return Scaffold(
      backgroundColor: const Color(0xffF7E6DA),
      appBar: AppBar(
        title: Text(
          department,
          style: const TextStyle(
            color: Color(0xffAD3306),
            fontWeight: FontWeight.bold,
          ),
        ),
        // centerTitle: true,
        backgroundColor: const Color(0xffF7E6DA),
      ),
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection('doctors')
              .where(
                'specialixationId',
                isEqualTo: departmentId,
              )
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
            if (snapshot.hasData) {
              var data = snapshot.data!.docs;
              var doctors = data.map((e) => e.data()).toList();
              if (doctors.isEmpty) {
                return const Center(
                  child: Text('No doctors available.'),
                );
              }
              return ListView.builder(
                itemBuilder: (context, index) {
                  if (doctors[index]['specialization'] == department) {
                    return InkWell(
                      onTap: () {
                        Navigator.of(context).pushNamed(
                          DoctorDetails.routeName,
                          arguments: {
                            'doctorId': doctors[index]['id'],
                          },
                        );
                      },
                      child: Card(
                        elevation: 3,
                        margin: const EdgeInsets.symmetric(vertical: 8),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                          // Add a border color
                          side: BorderSide(
                            color: Colors.grey.withOpacity(0.5),
                            width: 1,
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    doctors[index]['name'],
                                    style: const TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    doctors[index]['email'],
                                    style: const TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.normal,
                                      color: Colors.grey,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              decoration: BoxDecoration(
                                color: doctors[index]['online'] == true
                                    ? Colors.green.withOpacity(0.1)
                                    : Colors.red.withOpacity(0.1),
                                borderRadius: BorderRadius.only(
                                  bottomLeft: Radius.circular(10),
                                  bottomRight: Radius.circular(10),
                                ),
                              ),
                              padding: const EdgeInsets.all(12),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    doctors[index]['online'] == true
                                        ? 'Online'
                                        : 'Offline',
                                    style: TextStyle(
                                      color: doctors[index]['online'] == true
                                          ? Colors.green
                                          : Colors.red,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const Text(
                                    'View Details',
                                    style: TextStyle(
                                      color: Color(0xffAD3306),
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  } else {
                    return const SizedBox();
                  }
                },
                itemCount: doctors.length,
              );
            }
            return const Center(
              child: Text('No data available for this user.'),
            );
          },
        ),
      ),
    );
  }
}
