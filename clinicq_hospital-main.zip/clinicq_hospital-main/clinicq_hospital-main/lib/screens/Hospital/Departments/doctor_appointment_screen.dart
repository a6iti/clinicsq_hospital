// ignore_for_file: use_build_context_synchronously, avoid_print

// import 'dart:typed_data';

import 'package:clincq_hospital/screens/Hospital/Departments/file_handle_api.dart';
import 'package:clincq_hospital/screens/Hospital/Departments/pdf_invoice_api.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
// import 'file_handle_api.dart';
// import 'pdf_invoice_api.dart';
import 'dart:typed_data';

import 'package:pdf/widgets.dart' as pw;
import 'package:uuid/uuid.dart';
import 'package:http/http.dart' as http;

class DoctorAppointmentScreen extends StatefulWidget {
  const DoctorAppointmentScreen({super.key});
  static const routeName = '/doctor-appointment-screen';

  @override
  State<DoctorAppointmentScreen> createState() =>
      _DoctorAppointmentScreenState();
}

class _DoctorAppointmentScreenState extends State<DoctorAppointmentScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _reasonController = TextEditingController();
  final TextEditingController _bloodController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _genderController = TextEditingController();
  final TextEditingController _weightController = TextEditingController();
  final TextEditingController _heightController = TextEditingController();
  final TextEditingController _bpController = TextEditingController();
  final TextEditingController _feesController = TextEditingController();
  String convertTimestampToString(Timestamp timestamp) {
    // Convert Timestamp to DateTime
    DateTime dateTime = timestamp.toDate();

    // Format DateTime to desired string representation
    final DateFormat formatter =
        DateFormat('d\'${_getDaySuffix(dateTime.day)}\' MMMM, h:mma');
    return formatter.format(dateTime);
  }

  String _getDaySuffix(int day) {
    if (day >= 11 && day <= 13) {
      return 'th';
    }
    switch (day % 10) {
      case 1:
        return 'st';
      case 2:
        return 'nd';
      case 3:
        return 'rd';
      default:
        return 'th';
    }
  }

  PdfColor themeColor = PdfColors.black;
  pw.Font font = pw.Font.courier();

  var uuid = const Uuid();
  // create a method which takes a url and returns the image data

  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    final doctorEmail = args['email'];
    final doctorName = args['name'];
    final slotId = args['slotId'];
    final maxPatient = args['maxPatient'];
    final doctorId = args['doctorId'];
    final hospitalDetails = args['hospitalDetails'] as Map<String, String>;
    final designation = args['designation'];
    final phone = args['phone'];
    final registrationNumber = args['registrationNumber'];
    // final imageData = await fetchImageData(hospitalDetails['upiUrl']!);
    // print(hospitalDetails);
    // print(imageDetails);
    // create a map for doctor details
    print(hospitalDetails);
    Uint8List? imageData;
    final doctorDetails = {
      'name': doctorName,
      'email': doctorEmail,
      'designation': designation,
      'phone': phone,
      'registrationNumber': registrationNumber,
    };
    String qrLink = '';
    FirebaseFirestore.instance.collection('qr').doc('1').get().then((value) {
      // print('Value: $value');
      qrLink = value['qrLink'];
      print(qrLink);
    });
    print(qrLink);
    return Scaffold(
      backgroundColor: const Color(0xffF7E6DA),
      appBar: AppBar(
        title: Text(
          doctorName,
          style: const TextStyle(
            color: Color(0xffAD3306),
            fontWeight: FontWeight.bold,
          ),
        ),
        // centerTitle: true,
        backgroundColor: const Color(0xffF7E6DA),
      ),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection('appointments')
              .where('slotId', isEqualTo: slotId)
              .snapshots(),
          builder: (context, snapshot) {
            var index = 1;
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
            if (snapshot.hasData) {
              var appointments =
                  snapshot.data?.docs.map((e) => e.data()).toList();
              appointments = snapshot.data?.docs.map((e) => e.data()).toList();
              appointments?.sort(
                (a, b) => a['appointmentCreated'].compareTo(
                  b['appointmentCreated'],
                ),
              );
              // map to store appointment name and phone number
              // final patientDetails = {
              //   'name': appointments![0]['name'],
              //   'phone': appointments[0]['phone'],
              //   'age': appointments[0]['age'],
              //   'gender': appointments[0]['gender'],
              //   'bloodGroup': appointments[0]['bloodGroup'],
              //   'height': appointments[0]['height'],
              //   'weight': appointments[0]['weight'],
              //   'bp': appointments[0]['bp'],
              // };
              // print(patientDetails);

              if (appointments!.isEmpty) {
                return const Center(
                  child: Text(
                    'No appointments yet',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                );
              }
              int doneCount = appointments
                  .where((appointment) => appointment['status'] == 'ACCEPTED')
                  .length;

              int pendingCount = appointments
                  .where((appointment) => appointment['status'] == 'PENDING')
                  .length;

              return SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Text(hospitalDetails['name']!),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Maximum Slots = $maxPatient',
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.red,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        // create a button with text reserve
                        ElevatedButton(
                          child: Text('Reserve slot'),
                          onPressed: () async {
                            try {
                              var id = uuid.v4();
                              final appointmentData = FirebaseFirestore.instance
                                  .collection('appointments')
                                  .doc(id);
                              await appointmentData.set(
                                {
                                  'hospitalName': hospitalDetails['name'],
                                  'doctorName': doctorName,
                                  'doctorEmail': doctorEmail,
                                  'id': id,
                                  'name': 'Reserved',
                                  'phone': 'Reserved',
                                  'reason': 'Reserved',
                                  'appointmentCreated': DateTime.now(),
                                  'appointmentCreatedBy': 'HospitalReserved',
                                  'status': 'PENDING',
                                  'slotId': slotId,
                                  'doctorId': doctorId,
                                  'fees': 0,
                                  'feesPaid': false,
                                  'hasRated': false,
                                },
                              );
                              await FirebaseFirestore.instance
                                  .collection('slots')
                                  .doc(slotId)
                                  .update(
                                {
                                  'appointments': FieldValue.arrayUnion(
                                    [
                                      id,
                                    ],
                                  ),
                                },
                              );
                            } on Exception catch (e) {
                              print(e);
                              Navigator.of(context).pop();
                            }
                          },
                        ),
                      ],
                    ),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Taken Slots = ${appointments.length}',
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.black,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Text(
                          'Done Slots = $doneCount',
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.green,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Text(
                          'Pending Slots = $pendingCount',
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.orange,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                    // Image.network(hospitalDetails['upiUrl']!),
                    const SizedBox(height: 20),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * .65,
                      child: SingleChildScrollView(
                        child: Table(
                          border: TableBorder.all(
                            color: Colors.white,
                            width: 1.5,
                            style: BorderStyle.solid,
                          ),
                          defaultVerticalAlignment:
                              TableCellVerticalAlignment.middle,
                          children: [
                            TableRow(
                              decoration:
                                  const BoxDecoration(color: Color(0xffAD3306)),
                              children: [
                                _buildTableHeader('SrNo.'),
                                _buildTableHeader('Patient Name'),
                                _buildTableHeader('Reason'),
                                _buildTableHeader('Arrival Status'),
                                _buildTableHeader('Fees Status'),
                                _buildTableHeader('Print')
                              ],
                            ),
                            ...appointments.map(
                              (appointment) {
                                return TableRow(
                                  children: [
                                    // TableCell(child: Padding(
                                    //   padding: const EdgeInsets.all(8.0),
                                    //   child: Center(
                                    //     child: Text(
                                    //       (index++).toString(),
                                    //       style: const TextStyle(
                                    //         fontSize: 14,
                                    //       ),
                                    //     ),
                                    //   ),
                                    // ),),
                                    TableCell(
                                      child: InkWell(
                                        onTap: () {
                                          if (appointment[
                                                  'appointmentCreatedBy'] ==
                                              'HospitalReserved') {
                                            //create text field for name, phone, reason, fees and update the appointment
                                            showDialog(
                                              context: context,
                                              builder: (context) {
                                                return SingleChildScrollView(
                                                  child: AlertDialog(
                                                    title: const Text(
                                                        'Update Patient Details'),
                                                    content: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      children: [
                                                        TextField(
                                                          controller:
                                                              _nameController,
                                                          decoration:
                                                              const InputDecoration(
                                                            labelText: 'Name',
                                                          ),
                                                        ),
                                                        TextField(
                                                          keyboardType:
                                                              TextInputType
                                                                  .phone,
                                                          controller:
                                                              _phoneNumberController,
                                                          decoration:
                                                              const InputDecoration(
                                                            labelText:
                                                                'Phone Number',
                                                          ),
                                                        ),
                                                        TextField(
                                                          controller:
                                                              _reasonController,
                                                          decoration:
                                                              const InputDecoration(
                                                            labelText: 'Reason',
                                                          ),
                                                        ),
                                                        TextField(
                                                          keyboardType:
                                                              TextInputType
                                                                  .number,
                                                          controller:
                                                              _feesController,
                                                          decoration:
                                                              const InputDecoration(
                                                            labelText: 'Fees',
                                                          ),
                                                        ),
                                                        TextField(
                                                          controller:
                                                              _bloodController,
                                                          decoration:
                                                              const InputDecoration(
                                                            labelText:
                                                                'Blood Group(Optional)',
                                                          ),
                                                        ),
                                                        TextField(
                                                          controller:
                                                              _ageController,
                                                          decoration:
                                                              const InputDecoration(
                                                            labelText:
                                                                'Age(Optional)',
                                                          ),
                                                        ),
                                                        // gender, height, weight, bp
                                                        TextField(
                                                          controller:
                                                              _genderController,
                                                          decoration:
                                                              const InputDecoration(
                                                            labelText:
                                                                'Gender(Optional)',
                                                          ),
                                                        ),
                                                        TextField(
                                                          controller:
                                                              _weightController,
                                                          decoration:
                                                              const InputDecoration(
                                                            labelText:
                                                                'Weight(Optional)',
                                                          ),
                                                        ),
                                                        TextField(
                                                          controller:
                                                              _heightController,
                                                          decoration:
                                                              const InputDecoration(
                                                            labelText:
                                                                'Height(Optional)',
                                                          ),
                                                        ),
                                                        TextField(
                                                          controller:
                                                              _bpController,
                                                          decoration:
                                                              const InputDecoration(
                                                            labelText:
                                                                'Blood Pressure(Optional)',
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                    actions: [
                                                      TextButton(
                                                        child: Text('Update'),
                                                        onPressed: () async {
                                                         
                                                          
                                                          try {
                                                            await FirebaseFirestore
                                                                .instance
                                                                .collection(
                                                                    'appointments')
                                                                .doc(
                                                                    appointment[
                                                                        'id'])
                                                                .update({
                                                              'name': _nameController
                                                                          .text ==
                                                                      ''
                                                                  ? appointment[
                                                                      'name']
                                                                  : _nameController
                                                                      .text,
                                                              'phone':
                                                                  _phoneNumberController
                                                                      .text == ''?  appointment['phone']: _phoneNumberController.text,
                                                              'reason':
                                                                  _reasonController
                                                                      .text==''?appointment['reason']:_reasonController.text,
                                                              'fees': _feesController
                                                                          .text ==
                                                                      ''
                                                                  ? appointment[
                                                                      'fees']
                                                                  : int.parse(
                                                                      _feesController
                                                                          .text),
                                                              'bloodGroup': _bloodController
                                                                          .text ==
                                                                      ''
                                                                  ? appointment[
                                                                      'bloodGroup']
                                                                  : _bloodController
                                                                      .text,
                                                              'age': _ageController
                                                                          .text ==
                                                                      ''
                                                                  ? appointment[
                                                                      'age']
                                                                  : _ageController
                                                                      .text,
                                                              'gender': _genderController
                                                                          .text ==
                                                                      ''
                                                                  ? appointment[
                                                                      'gender']
                                                                  : _genderController
                                                                      .text,
                                                              'weight': _weightController
                                                                          .text ==
                                                                      ''
                                                                  ? appointment[
                                                                      'weight']
                                                                  : _weightController
                                                                      .text,
                                                              'height': _heightController
                                                                          .text ==
                                                                      ''
                                                                  ? appointment[
                                                                      'height']
                                                                  : _heightController
                                                                      .text,
                                                              'bp': _bpController
                                                                          .text ==
                                                                      ''
                                                                  ? appointment[
                                                                      'bp']
                                                                  : _bpController
                                                                      .text,
                                                            });
                                                            Navigator.pop(
                                                                context);
                                                          } on Exception catch (e) {
                                                            print(e);
                                                            Navigator.of(context)
                                                                .pop();
                                                          }
                                                        },
                                                      ),
                                                      TextButton(
                                                        child: Text('Cancel'),
                                                        onPressed: () {
                                                          Navigator.of(context)
                                                              .pop();
                                                        },
                                                      ),
                                                    ],
                                                  ),
                                                );
                                              },
                                            );
                                          }
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Center(
                                            child: Column(
                                              children: [
                                                Text(
                                                  (index++).toString(),
                                                  style: const TextStyle(
                                                    fontSize: 14,
                                                  ),
                                                ),
                                                if (appointment[
                                                        'appointmentCreatedBy'] ==
                                                    'HospitalReserved')
                                                  Icon(
                                                    Icons.edit,
                                                    color: Colors.red,
                                                    size: 20,
                                                  ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    TableCell(
                                      child: InkWell(
                                        onTap: () {
                                          showDialog(
                                            context: context,
                                            builder: (BuildContext context) {
                                              return AlertDialog(
                                                title: const Text(
                                                  'Patient Details',
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    fontSize:
                                                        24, // Increased title font size
                                                  ),
                                                ),
                                                content: SizedBox(
                                                  width: double.maxFinite,
                                                  child: Column(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    // crossAxisAlignment:
                                                    //     CrossAxisAlignment.start,
                                                    children: [
                                                      const SizedBox(
                                                          height:
                                                              12), // Add space between title and content
                                                      Text(
                                                        'Name: ${appointment['name']}',
                                                        style: const TextStyle(
                                                          fontSize: 20,
                                                        ),
                                                      ),
                                                      const SizedBox(
                                                          height:
                                                              8), // Add space between fields
                                                      Text(
                                                        'Phone: ${appointment['phone']}',
                                                        style: const TextStyle(
                                                          fontSize: 20,
                                                        ),
                                                      ),
                                                      const SizedBox(
                                                          height:
                                                              8), // Add space between fields
                                                      Text(
                                                        'Reason: ${appointment['reason']}',
                                                        style: const TextStyle(
                                                          fontSize: 20,
                                                        ),
                                                      ),
                                                      const SizedBox(
                                                          height:
                                                              8), // Add space between fields
                                                      Text(
                                                        'Booking Time: ${convertTimestampToString(appointment['appointmentCreated'])}',
                                                        style: const TextStyle(
                                                          fontSize: 20,
                                                        ),
                                                      ),
                                                      const SizedBox(
                                                          height:
                                                              8), // Add space between fields
                                                      // show blood group, gender, height, weight age, bp if available
                                                      if (appointment[
                                                              'bloodGroup'] !=
                                                          null)
                                                        Text(
                                                          'Blood Group: ${appointment['bloodGroup']}',
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 20,
                                                          ),
                                                        ),
                                                      if (appointment['age'] !=
                                                          null)
                                                        Text(
                                                          'Age: ${appointment['age']}',
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 20,
                                                          ),
                                                        ),
                                                      if (appointment[
                                                              'gender'] !=
                                                          null)
                                                        Text(
                                                          'Gender: ${appointment['gender']}',
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 20,
                                                          ),
                                                        ),
                                                      // do same for height, weight, bp
                                                      if (appointment[
                                                              'height'] !=
                                                          null)
                                                        Text(
                                                          'Height: ${appointment['height']}',
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 20,
                                                          ),
                                                        ),

                                                      if (appointment[
                                                              'weight'] !=
                                                          null)
                                                        Text(
                                                          'Weight: ${appointment['weight']}',
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 20,
                                                          ),
                                                        ),
                                                      if (appointment['bp'] !=
                                                          null)
                                                        Text(
                                                          'Blood Pressure: ${appointment['bp']}',
                                                          style:
                                                              const TextStyle(
                                                            fontSize: 20,
                                                          ),
                                                        ),
                                                    ],
                                                  ),
                                                ),
                                                actions: <Widget>[
                                                  TextButton(
                                                    onPressed: () {
                                                      Navigator.of(context)
                                                          .pop();
                                                    },
                                                    child: const Text('Close'),
                                                  ),
                                                ],
                                              );
                                            },
                                          );
                                        },
                                        child: Text(
                                          appointment['name'],
                                          style: const TextStyle(
                                            fontSize: 14,
                                          ),
                                        ),
                                      ),
                                    ),
                                    TableCell(
                                      child: InkWell(
                                        onTap: () {
                                          showDialog(
                                            context: context,
                                            builder: (BuildContext context) {
                                              return AlertDialog(
                                                title: const Text(
                                                    'Reason for visit',
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold)),
                                                content: Text(
                                                  appointment['reason'],
                                                  style: const TextStyle(
                                                      fontSize: 20),
                                                ),
                                                actions: <Widget>[
                                                  TextButton(
                                                    onPressed: () {
                                                      Navigator.of(context)
                                                          .pop();
                                                    },
                                                    child: const Text('Close'),
                                                  ),
                                                ],
                                              );
                                            },
                                          );
                                        },
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Center(
                                            child: SingleChildScrollView(
                                              scrollDirection: Axis.horizontal,
                                              child: Text(
                                                appointment['reason'],
                                                style: const TextStyle(
                                                  fontSize: 14,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    TableCell(
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Center(
                                          child: AppointmentAction(
                                            status: appointment['status'],
                                            appointmentId: appointment['id'],
                                            slotId: slotId,
                                            appointmentCreatedBy: appointment[
                                                'appointmentCreatedBy'],
                                          ),
                                        ),
                                      ),
                                    ),
                                    TableCell(
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Center(
                                          child: FeesAction(
                                            feesStatus: appointment['feesPaid'],
                                            appointmentId: appointment['id'],
                                            slotId: slotId,
                                            appointmentCreatedBy: appointment[
                                                'appointmentCreatedBy'],
                                          ),
                                        ),
                                      ),
                                    ),
                                    TableCell(
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Center(
                                          child: GestureDetector(
                                            onTap: () async {
                                              final confirm =
                                                  await showDialog<bool>(
                                                context: context,
                                                builder: (context) =>
                                                    AlertDialog(
                                                  title: Text('Confirm'),
                                                  content: const Text(
                                                    'Prescription generation will take few seconds',
                                                  ),
                                                  actions: [
                                                    TextButton(
                                                      child: Text('Cancel'),
                                                      onPressed: () =>
                                                          Navigator.of(context)
                                                              .pop(false),
                                                    ),
                                                    TextButton(
                                                      child: Text('Proceed'),
                                                      onPressed: () =>
                                                          Navigator.of(context)
                                                              .pop(true),
                                                    ),
                                                  ],
                                                ),
                                              );

                                              if (confirm == true) {
                                                // use the hospital detail to fetch hospital id and then use it to increase the count of appointments
                                                final hospitalId =
                                                    hospitalDetails['id'];
                                                final hospitalRef =
                                                    FirebaseFirestore.instance
                                                        .collection('hospitals')
                                                        .doc(hospitalId);
                                                ScaffoldMessenger.of(context)
                                                    .showSnackBar(
                                                  const SnackBar(
                                                    content: Text(
                                                        'Prescription is being generated'),
                                                  ),
                                                );

                                                // Increment the printCount field
                                                await hospitalRef.update({
                                                  'printCount':
                                                      FieldValue.increment(1)
                                                });
                                                // show snackbar to show the prescription is being generated
                                                ScaffoldMessenger.of(context)
                                                    .showSnackBar(
                                                  const SnackBar(
                                                    content: Text(
                                                        'Prescription is being generated'),
                                                  ),
                                                );

                                                final pdfFile =
                                                    await PdfInvoiceApi
                                                        .generate(
                                                            themeColor,
                                                            pw.Font.courier(),
                                                            hospitalDetails,
                                                            doctorDetails,
                                                            appointment,
                                                            index,
                                                            qrLink);

                                                // opening the pdf file
                                                FileHandleApi.openFile(pdfFile);
                                              }
                                            },
                                            child: const Icon(
                                              Icons.payment,
                                              color: Colors.green,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              );
            } else {
              return const Center(
                child: Text('No doctors available'),
              );
            }
          },
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: Theme.of(context).primaryColor,
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) {
              return SingleChildScrollView(
                child: AlertDialog(
                  title: const Text('Add a new Patient'),
                  content: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextField(
                        controller: _nameController,
                        decoration: const InputDecoration(
                          labelText: 'Name',
                        ),
                      ),
                      TextField(
                        keyboardType: TextInputType.phone,
                        controller: _phoneNumberController,
                        decoration: const InputDecoration(
                          labelText: 'Phone Number',
                        ),
                      ),
                      TextField(
                        controller: _reasonController,
                        decoration: const InputDecoration(
                          labelText: 'Reason',
                        ),
                      ),
                      TextField(
                        keyboardType: TextInputType.number,
                        controller: _feesController,
                        decoration: const InputDecoration(
                          labelText: 'Fees',
                        ),
                      ),
                      TextField(
                        controller: _bloodController,
                        decoration: const InputDecoration(
                          labelText: 'Blood Group(Optional)',
                        ),
                      ),
                      TextField(
                        controller: _ageController,
                        decoration: const InputDecoration(
                          labelText: 'Age(Optional)',
                        ),
                      ),
                      TextField(
                        controller: _genderController,
                        decoration: const InputDecoration(
                          labelText: 'Gender(Optional)',
                        ),
                      ),
                      TextField(
                        controller: _weightController,
                        decoration: const InputDecoration(
                          labelText: 'Weight(Optional)',
                        ),
                      ),
                      TextField(
                        controller: _heightController,
                        decoration: const InputDecoration(
                          labelText: 'Height(Optional)',
                        ),
                      ),
                      TextField(
                        controller: _bpController,
                        decoration: const InputDecoration(
                          labelText: 'Blood Pressure(Optional)',
                        ),
                      ),
                    ],
                  ),
                  actions: [
                    TextButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: const Text('Cancel'),
                    ),
                    TextButton(
                      onPressed: () async {
                        if (_nameController.text.isEmpty ||
                            _phoneNumberController.text.isEmpty ||
                            _reasonController.text.isEmpty ||
                            _feesController.text.isEmpty) {
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title: const Text('Error'),
                                content:
                                    const Text('Please fill all the details'),
                                actions: <Widget>[
                                  TextButton(
                                    child: const Text('OK'),
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                  ),
                                ],
                              );
                            },
                          );
                        } else if (_phoneNumberController.text.length != 10) {
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title: const Text('Error'),
                                content: const Text(
                                    'Please enter a valid phone number'),
                                actions: <Widget>[
                                  TextButton(
                                    child: const Text('OK'),
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                  ),
                                ],
                              );
                            },
                          );
                        } else {
                          // add appointment to database
                          showDialog(
                            context: context,
                            barrierDismissible: false,
                            builder: (context) => const Center(
                              child: CircularProgressIndicator(),
                            ),
                          );
                          try {
                            var id = uuid.v4();
                            final appointmentData = FirebaseFirestore.instance
                                .collection('appointments')
                                .doc(id);
                            await appointmentData.set(
                              {
                                'hospitalName': hospitalDetails['name'],
                                'doctorName': doctorName,
                                'doctorEmail': doctorEmail,
                                'id': id,
                                'name': _nameController.text,
                                'phone': _phoneNumberController.text,
                                'reason': _reasonController.text,
                                'appointmentCreated': DateTime.now(),
                                'appointmentCreatedBy': 'Hospital',
                                'status': 'PENDING',
                                'slotId': slotId,
                                'doctorId': doctorId,
                                'fees': int.parse(_feesController.text),
                                'feesPaid': false,
                                'hasRated': false,
                                'bloodGroup': _bloodController.text,
                                'age': _ageController.text,
                                'gender': _genderController.text,
                                'weight': _weightController.text,
                                'height': _heightController.text,
                                'bp': _bpController.text,
                              },
                            );
                            await FirebaseFirestore.instance
                                .collection('slots')
                                .doc(slotId)
                                .update(
                              {
                                'appointments': FieldValue.arrayUnion(
                                  [
                                    id,
                                  ],
                                ),
                              },
                            );
                            Navigator.pop(context);
                            Navigator.pop(context);
                          } on Exception catch (e) {
                            print(e);
                            Navigator.pop(context);
                          }
                        }
                      },
                      child: const Text('Confirm'),
                    ),
                  ],
                ),
              );
            },
          );
        },
        label: const Text(
          'Add New Patient',
          style: TextStyle(
              color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
        ),
      ),
    );
  }

  Widget _buildTableHeader(String text) {
    return Container(
      padding: const EdgeInsets.all(8.0),
      alignment: Alignment.center,
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.w500,
          color: Colors.white,
        ),
      ),
    );
  }
}

class AppointmentAction extends StatefulWidget {
  const AppointmentAction({
    super.key,
    required this.status,
    required this.appointmentId,
    required this.slotId,
    required this.appointmentCreatedBy,
  });

  final String? status;
  final String? appointmentId;
  final String? slotId;
  final String? appointmentCreatedBy;

  @override
  State<AppointmentAction> createState() => _AppointmentActionState();
}

class _AppointmentActionState extends State<AppointmentAction> {
  @override
  Widget build(BuildContext context) {
    return widget.status == "PENDING"
        ? Column(
            children: [
              IconButton(
                onPressed: () async {
                  try {
                    await FirebaseFirestore.instance
                        .collection('appointments')
                        .doc(widget.appointmentId)
                        .update({
                      'status': 'ACCEPTED',
                      'acceptanceTime': DateTime.now(),
                    });
                  } on Exception catch (e) {
                    print(e);
                    Navigator.of(context).pop();
                  }
                },
                icon: const Icon(
                  Icons.check,
                  color: Colors.green,
                ),
              ),
              IconButton(
                onPressed: () async {
                  try {
                    await FirebaseFirestore.instance
                        .collection('appointments')
                        .doc(widget.appointmentId)
                        .update({
                      'status': 'REJECTED',
                      'acceptanceTime': DateTime.now(),
                    });
                    await FirebaseFirestore.instance
                        .collection('users')
                        .doc(widget.appointmentCreatedBy)
                        .update(
                      {
                        'appointments':
                            FieldValue.arrayRemove([widget.appointmentId])
                      },
                    );
                  } on Exception catch (e) {
                    print(e);
                  }
                },
                icon: const Icon(
                  Icons.close,
                  color: Colors.red,
                ),
              ),
            ],
          )
        : widget.status == "ACCEPTED"
            ? const Text(
                'DONE',
                style: TextStyle(
                  color: Colors.green,
                  fontWeight: FontWeight.w500,
                ),
              )
            : const SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Text(
                  'REJECTED',
                  style: TextStyle(
                    color: Colors.red,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              );
  }
}

class FeesAction extends StatefulWidget {
  const FeesAction({
    super.key,
    required this.feesStatus,
    required this.appointmentId,
    required this.slotId,
    required this.appointmentCreatedBy,
  });

  final bool feesStatus;
  final String? appointmentId;
  final String? slotId;
  final String? appointmentCreatedBy;

  @override
  State<FeesAction> createState() => _FeesActionState();
}

class _FeesActionState extends State<FeesAction> {
  @override
  Widget build(BuildContext context) {
    return !widget.feesStatus
        ? Column(
            children: [
              IconButton(
                onPressed: () async {
                  try {
                    await FirebaseFirestore.instance
                        .collection('appointments')
                        .doc(widget.appointmentId)
                        .update({
                      'feesPaid': true,
                    });
                    // Navigator.of(context).pop();
                  } on Exception catch (e) {
                    print(e);
                    Navigator.of(context).pop();
                  }
                },
                icon: const Icon(
                  Icons.check,
                  color: Colors.green,
                ),
              ),
            ],
          )
        : const Text(
            'PAID',
            style: TextStyle(
              color: Colors.green,
              fontWeight: FontWeight.w500,
            ),
          );
  }
}
