// ignore_for_file: use_build_context_synchronously, avoid_print

import 'package:clincq_hospital/providers/hospital_auth_provider.dart';
import 'package:clincq_hospital/screens/Hospital/Departments/department_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

class DepartmentHomeScreen extends StatefulWidget {
  const DepartmentHomeScreen({super.key});

  @override
  State<DepartmentHomeScreen> createState() => _DepartmentHomeScreenState();
}

class _DepartmentHomeScreenState extends State<DepartmentHomeScreen> {
  final user = FirebaseAuth.instance.currentUser!;
  final TextEditingController _departmentNameController =
      TextEditingController();
  late String hospitalId;
  late Future<String> _fetchHospitalIdFuture;

  @override
  void initState() {
    super.initState();
    _fetchHospitalIdFuture = _fetchHospitalId();
  }

  Future<String> _fetchHospitalId() async {
    try {
      final hospitalId = await Provider.of<HospitalAuth>(
        context,
        listen: false,
      ).fetchHospitalId(
        user.email!,
      );
      return hospitalId;
    } catch (e) {
      print("Error fetching hospital ID: $e");
      rethrow; // Rethrow the error to handle it in FutureBuilder
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<String>(
      future: _fetchHospitalIdFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        } else if (snapshot.hasError) {
          return Scaffold(
            body: Center(
              child: Text("Error: ${snapshot.error}"),
            ),
          );
        } else {
          return _buildDepartmentScreen(snapshot.data!);
        }
      },
    );
  }

  String searchQuery = '';
  Widget _buildDepartmentScreen(String hospitalId) {
    // get filtered departments
    List<dynamic> getFilteredDepartments(List<dynamic> doctorArray) {
      if (searchQuery.isNotEmpty) {
        return doctorArray.where((department) {
          String name = department['name'].toString().toLowerCase();
          // String specialization =
          //     department['specialization'].toString().toLowerCase();
          String query = searchQuery.toLowerCase();

          return name.contains(query);
        }).toList();
        // .where((element) => element['hospitalId'] == hospitalId)
        // .toList();
      } else {
        return doctorArray;
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Departments',
          style: TextStyle(
            color: Color(0xffAD3306),
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: const Color(0xffF7E6DA),
        // centerTitle: true,ß
      ),
      backgroundColor: const Color(0xffF7E6DA),
      body: Padding(
        padding: const EdgeInsets.all(18.0),
        child: Column(
          children: [
            TextField(
              onChanged: (value) {
                // print(value);
                setState(() {
                  searchQuery = value;
                });
              },
              decoration: const InputDecoration(
                focusColor: Color(0xffAD3306),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  borderSide: BorderSide(width: 10),
                ),
                contentPadding:
                    EdgeInsets.symmetric(vertical: 10, horizontal: 8),
                hintText: 'Search for departments...',
                prefixIcon: Icon(
                  Icons.search,
                  color: Color(0xffAD3306),
                ),
                filled: false, // enable fill color
              ),
            ),
            const SizedBox(
              height: 16,
            ),
            Expanded(
              child: StreamBuilder(
                stream: FirebaseFirestore.instance
                    .collection('departments')
                    .where('hospitalId', isEqualTo: hospitalId)
                    .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(
                      child: CircularProgressIndicator(),
                    );
                  } else if (!snapshot.hasData) {
                    return const Center(
                      child: Text('Add a department to get started.'),
                    );
                  } else {
                    var data = snapshot.data!.docs;
                    var departments = data.map((e) => e.data()).toList();

                    return ListView.builder(
                      itemCount: getFilteredDepartments(departments).length,
                      itemBuilder: (context, index) {
                        var sortedDepartments = getFilteredDepartments(
                            departments)
                          ..sort((a, b) => (a['name'] as String)
                              .toLowerCase()
                              .compareTo((b['name'] as String).toLowerCase()));
                        var department = sortedDepartments[index];
                        // var department = departments[index];
                        return Card(
                          elevation: 3,
                          margin: const EdgeInsets.symmetric(vertical: 8),
                          child: ListTile(
                            onTap: () {
                              Navigator.pushNamed(
                                context,
                                DepartmentScreen.routeName,
                                arguments: {
                                  'department': department['name'] as String,
                                  'departmentId': department['id'],
                                },
                              );
                            },
                            title: Text(
                              department['name'] as String,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            trailing: IconButton(
                              onPressed: () {
                                _deleteDepartment(department, hospitalId);
                              },
                              icon: const Icon(
                                Icons.delete,
                                color: Colors.red,
                              ),
                            ),
                          ),
                        );
                      },
                    );
                  }
                },
              ),
            ),
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.07,
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: Theme.of(context).primaryColor,
        onPressed: _showAddDepartmentDialog,
        label: const Text(
          'Add Department',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 14,
          ),
        ),
      ),
    );
  }

  void _showAddDepartmentDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Add a new Department'),
          content: TextField(
            controller: _departmentNameController,
            decoration: const InputDecoration(
              labelText: 'Department Name',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: _addDepartment,
              child: const Text('Add'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _addDepartment() async {
    final hospitalAuth = Provider.of<HospitalAuth>(
      context,
      listen: false,
    );
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: CircularProgressIndicator(),
      ),
    );
    try {
      final hospitalId = await hospitalAuth.fetchHospitalId(
        user.email!,
      );
      final uid = const Uuid().v4();
      await FirebaseFirestore.instance.collection('departments').doc(uid).set({
        'id': uid,
        'name': _departmentNameController.text,
        'doctors': [],
        'hospitalId': hospitalId,
      });
      await FirebaseFirestore.instance
          .collection('hospitals')
          .doc(hospitalId)
          .update({
        'specialization': FieldValue.arrayUnion(
          [
            uid,
          ],
        ),
      });
    } on Exception catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString()),
        ),
      );
    } finally {
      Navigator.of(context).pop();
      Navigator.of(context).pop();
    }
  }

  void _deleteDepartment(
    Map<String, dynamic> department,
    String hid,
  ) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Confirm Deletion'),
          content:
              const Text('Are you sure you want to delete this department?'),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () {
                _confirmDeleteDepartment(
                  department,
                  hid,
                );
                Navigator.of(context).pop(); // Close the dialog
              },
              child: const Text(
                'Delete',
                style: TextStyle(color: Colors.red),
              ),
            ),
          ],
        );
      },
    );
  }

  void _confirmDeleteDepartment(
    Map<String, dynamic> department,
    String hid,
  ) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => const Center(
        child: CircularProgressIndicator(),
      ),
    );
    try {
      await FirebaseFirestore.instance
          .collection('departments')
          .doc(department['id'])
          .delete();
      await FirebaseFirestore.instance.collection('hospitals').doc(hid).update({
        'specialization': FieldValue.arrayRemove(
          [
            department['id'],
          ],
        ),
      });
      Navigator.of(context).pop(); // Close the loading dialog
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Department deleted successfully.'),
        ),
      );
    } catch (e) {
      Navigator.of(context).pop(); // Close the loading dialog
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to delete department: $e'),
        ),
      );
    }
  }
}
