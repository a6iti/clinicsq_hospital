import 'package:clincq_hospital/screens/Hospital/Departments/doctor_appointment_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class DoctorProfile extends StatefulWidget {
  const DoctorProfile({super.key});

  static const routeName = '/department/profile';

  @override
  State<DoctorProfile> createState() => _DoctorProfileState();
}

class _DoctorProfileState extends State<DoctorProfile> {
  late DateTime selectedDate;

  @override
  void initState() {
    super.initState();
    selectedDate = DateTime.now();
  }

  String _getDaySuffix(int day) {
    if (day >= 11 && day <= 13) {
      return 'th';
    }
    switch (day % 10) {
      case 1:
        return 'st';
      case 2:
        return 'nd';
      case 3:
        return 'rd';
      default:
        return 'th';
    }
  }

  String _formatTime(String time) {
    final parts = time.split(":");
    var hour = int.parse(parts[0]);

    // Determine AM/PM
    String period = 'AM';
    if (hour >= 12) {
      period = 'PM';
      if (hour > 12) hour -= 12;
    }

    // Format time
    return '$hour:${parts[1]} $period';
  }

  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    final doctorEmail = args['email'];
    final doctorName = args['name'];
    final doctorId = args['doctorId'];
    final designation = args['designation'];
    final registrationNumber = args['registrationNumber'];
    final phone = args['phone'];
    // hospitalDetails is a map of string string, receive it from the previous screen
    final hospitalDetails = args['hospitalDetails'] as Map<String, String>;
    

    return Scaffold(
      appBar: AppBar(
        title: Text(
          doctorName,
          style: const TextStyle(
            color: Color(0xffAD3306),
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: const Color(0xffF7E6DA),
      ),
      backgroundColor: const Color(0xffF7E6DA),
      body: Column(
        children: [
          // Text(
          //   hospitalDetails['name']!,
          //   style: const TextStyle(
          //     fontSize: 16,
          //     fontWeight: FontWeight.bold,
          //     color: Color(0xffAD3306),
          //   ),
          // ),
          Padding(
            padding: const EdgeInsets.only(left: 18, right: 18, top: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Select Date: ',
                  style: TextStyle(
                    fontSize: 16,
                    color: Color(0xffAD3306),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(width: 20),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(15),
                    color: Theme.of(context).primaryColor,
                  ),
                  child: TextButton.icon(
                    onPressed: () {
                      _selectDate(context);
                    },
                    icon: const Icon(
                      Icons.calendar_today,
                      color: Colors.white,
                      size: 13,
                    ),
                    label: Text(
                      '${DateFormat('E,').format(selectedDate)} ${DateFormat('d').format(selectedDate)}${_getDaySuffix(selectedDate.day)} ${DateFormat('MMM y').format(selectedDate)}',
                      style: const TextStyle(
                        fontSize: 13,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection('slots')
                  .where('doctorId', isEqualTo: doctorId)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                }
                if (snapshot.hasData) {
                  var data = snapshot.data!.docs;
                  var slots = data.map((e) => e.data()).toList();
                  var filteredSlots = slots.where((slot) {
                    var slotDate = DateTime.parse(slot['date']);
                    return slotDate.year == selectedDate.year &&
                        slotDate.month == selectedDate.month &&
                        slotDate.day == selectedDate.day;
                  }).toList();
                  if (filteredSlots.isEmpty) {
                    return Center(
                      child: Text(
                        'No slots available for ${DateFormat('E,').format(selectedDate)} '
                        '${DateFormat('d').format(selectedDate)}${_getDaySuffix(selectedDate.day)} '
                        '${DateFormat('MMM y').format(selectedDate)}',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    );
                  }
                  return ListView.builder(
                    itemBuilder: (context, index) {
                      return Card(
                        elevation: 4,
                        margin: const EdgeInsets.symmetric(
                            vertical: 8, horizontal: 16),
                        child: ListTile(
                          title: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Max Patients: ${filteredSlots[index]['maxpatient']}',
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.orange,
                                ),
                              ),
                              Row(
                                children: [
                                  Text(
                                    'Timings: ${_formatTime(filteredSlots[index]['starttime'])}',
                                    style: const TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    ' - ${_formatTime(filteredSlots[index]['endtime'])}',
                                    style: const TextStyle(
                                      fontSize: 14,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                          trailing: SizedBox(
                            width: MediaQuery.of(context).size.width * .25,
                            child: InkWell(
                              onTap: () {
                                Navigator.pushNamed(
                                  context,
                                  DoctorAppointmentScreen.routeName,
                                  arguments: {
                                    'email': doctorEmail,
                                    'name': doctorName,
                                    'slotIndex': index,
                                    'doctorId': doctorId,
                                    'slotId': filteredSlots[index]['id'],
                                    'maxPatient': filteredSlots[index]
                                        ['maxpatient'],
                                    'hospitalDetails': hospitalDetails,
                                    'designation': designation,
                                    'registrationNumber': registrationNumber,
                                    'phone': phone,
                                  },
                                );
                              },
                              child: Text(
                                'View Appointments',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  color: Theme.of(context).primaryColor,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                    itemCount: filteredSlots.length,
                  );
                } else {
                  return const Center(
                    child: Text('No slots available'),
                  );
                }
              },
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(1900), // Set to a date far in the past
      lastDate: DateTime.now().add(const Duration(days: 7)),
    );
    if (pickedDate != null && pickedDate != selectedDate) {
      setState(() {
        selectedDate = pickedDate;
      });
    }
  }
}
