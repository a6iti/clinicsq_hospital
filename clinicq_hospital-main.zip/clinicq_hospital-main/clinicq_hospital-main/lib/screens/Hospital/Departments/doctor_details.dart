import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class DoctorDetails extends StatefulWidget {
  const DoctorDetails({super.key});
  static const routeName = '/doctor-details';

  @override
  State<DoctorDetails> createState() => _DoctorDetailsState();
}

class _DoctorDetailsState extends State<DoctorDetails> {
  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    final doctorId = args['doctorId'];
    return Scaffold(
      appBar: AppBar(
        // primary app color: 0xffAD3306
        backgroundColor: const Color(0xffAD3306),
        title: const Text(
          'Profile',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('doctors')
            .doc(doctorId)
            .snapshots(),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.hasData) {
            if (snapshot.data!['profileVerified'] == false) {
              return const Center(
                child: Text(
                  'Profile not verified by the administrator',
                  style: TextStyle(color: Colors.red, fontSize: 16),
                ),
              );
            } else {
              return SingleChildScrollView(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    InkWell(
                      onTap: () {
                        showDialog(
                          context: context,
                          builder: (context) {
                            return Dialog(
                              child: Image.network(
                                snapshot.data!['profileImageUrl'],
                                fit: BoxFit.contain,
                              ),
                            );
                          },
                        );
                      },
                      child: CircleAvatar(
                        radius: 50,
                        backgroundImage: NetworkImage(
                          snapshot.data!['profileImageUrl'],
                        ),
                      ),
                    ),

                    // Add your ProfileField widgets here...
                    const SizedBox(
                      height: 20,
                    ),
                    ProfileField(
                      title: 'Title',
                      value: snapshot.data!['title'],
                    ),
                    ProfileField(
                      title: 'Name',
                      value: snapshot.data!['name'],
                    ),
                    ProfileField(
                        title: 'Designation',
                        value: snapshot.data!['designation']),
                    ProfileField(
                      title: 'Bio',
                      value: snapshot.data!['bio'],
                    ),
                    ProfileField(
                      title: 'Gender',
                      value: snapshot.data!['gender'],
                    ),
                    ProfileField(
                      title: 'First time fees',
                      value: snapshot.data!['firstTimeFees'].toString(),
                    ),
                    ProfileField(
                      title: 'Normal fees',
                      value: snapshot.data!['normalFees'].toString(),
                    ),
                    ProfileField(
                      title: 'Email',
                      value: snapshot.data!['email'] ?? '',
                    ),
                    ProfileField(
                      title: 'Email',
                      value: snapshot.data!['email'] ?? '',
                    ),
                    ProfileField(
                      title: 'Year',
                      value: snapshot.data!['year'],
                    ),
                    ProfileField(
                      title: 'Department',
                      value: snapshot.data!['specialization'],
                    ),
                    ProfileField(
                      title: 'Phone',
                      value: snapshot.data!['phone'],
                    ),
                    ProfileField(
                      title: 'College',
                      value: snapshot.data!['college'],
                    ),
                    ProfileField(
                      title: 'Degree',
                      value: snapshot.data!['degree'],
                    ),
                    ProfileField(
                      title: 'Experience',
                      value: snapshot.data!['experience'],
                    ),

                    const SizedBox(
                      height: 50,
                    ),
                  ],
                ),
              );
            }
          } else if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          } else {
            return const Center(
              child: Text('No data available for this user.'),
            );
          }
        },
      ),
    );
  }
}

class ProfileField extends StatelessWidget {
  final String title;
  final String value;

  const ProfileField({super.key, required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      elevation: 4,
      child: ListTile(
        title: Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        subtitle: Text(
          value,
          style: const TextStyle(fontSize: 14),
        ),
      ),
    );
  }
}
