import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'file_handle_api.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:http/http.dart' as http;

class PdfInvoiceApi {
  static Future<File> generate(
      PdfColor color,
      pw.Font fontFamily,
      Map<String, dynamic> hospitalDetails,
      Map<String, dynamic> doctorDetails,
      Map<String, dynamic> patientDetails,
      var index,
      String qrLink
      // Uint8List ?imageData,
      ) async {
    final pdf = pw.Document();
    Future<Uint8List> fetchImageData(String url) async {
      final response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        return response.bodyBytes;
      } else {
        throw Exception('Failed to load image data: ${response.statusCode}');
      }
    }

    final imageData = await fetchImageData(hospitalDetails['upiUrl']);
    final image = pw.MemoryImage(imageData);

    final qrData = await fetchImageData(qrLink);
    final qr = pw.MemoryImage(qrData);

    final cqLogo =
        (await rootBundle.load('assets/logo.png')).buffer.asUint8List();
    final PdfColor hospitalNameColor = PdfColor.fromInt(0xffAD3306);
    final PdfColor green = PdfColor.fromInt(0xff006400);
    pdf.addPage(
      pw.Page(
        build: (context) {
          return pw.Container(
            padding: pw.EdgeInsets.all(-25),
                        child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.stretch,
            children: [
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.center,
                children: [
                  pw.Container(
                    alignment: pw.Alignment.center,
                    child: pw.Text(
                      hospitalDetails['name'] ?? '',
                      style: pw.TextStyle(
                        fontSize: 40.0,
                        fontWeight: pw.FontWeight.bold,
                        color: hospitalNameColor,
                        font: fontFamily,
                      ),
                    ),
                  ),
                  pw.SizedBox(width: 10),
                  // if(image!=null)
                  pw.Center(
                    child: pw.Image(image, height: 50),
                  ),
                ],
              ),

              // pw.Container(
              //   // height: 100,
              //   // width: 100,
              //   alignment: pw.Alignment.center,
              //   child: pw.BarcodeWidget(
              //     barcode: pw.Barcode.qrCode(),
              //     data: hospitalDetails['upiUrl'] ?? '',
              //     color: color,
              //     width: 150,
              //     height: 150
              //   ),
              // ),

              pw.SizedBox(height: 20),
              pw.Row(
                crossAxisAlignment: pw.CrossAxisAlignment.center,
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Expanded(
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text(
                          // 'Doctor Name     : ${doctorDetails['name'] ?? ''}',
                          'Dr. ${doctorDetails['name'] ?? ''}',
                          style: pw.TextStyle(
                            fontSize: 12.0,
                            color: green,
                            font: fontFamily,
                            fontWeight: pw.FontWeight.bold,
                          ),
                        ),
                        pw.Text(
                          // 'Designation     : ${doctorDetails['designation'] ?? ''}',
                          '${doctorDetails['designation'] ?? ''}',

                          style: pw.TextStyle(
                            fontSize: 12.0,
                            color: green,
                            font: fontFamily,
                          ),
                        ),
                        pw.Text(
                          // 'Registration No.: ${doctorDetails['registrationNumber'] ?? ''}',
                          '${doctorDetails['registrationNumber'] ?? ''}',
                          style: pw.TextStyle(
                            fontSize: 12.0,
                            color: green,
                            font: fontFamily,
                          ),
                        ),
                        pw.Text(
                          // 'Phone No.       : ${doctorDetails['phone'] ?? ''}',
                          '${doctorDetails['phone'] ?? ''}',
                          style: pw.TextStyle(
                            fontSize: 12.0,
                            color: green,
                            font: fontFamily,
                          ),
                        ),
                      ],
                    ),
                  ),
                  pw.SizedBox(width: 20),
                  pw.Expanded(
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Align(
                          alignment: pw.Alignment.centerRight,
                          child: pw.Text(
                            // 'Address  : ${hospitalDetails['locality'] ?? ''}, ${hospitalDetails['city'] ?? ''}-${hospitalDetails['postalCode'] ?? ''},${hospitalDetails['state'] ?? ''}',
                            '${hospitalDetails['locality'] ?? ''}',
                            style: pw.TextStyle(
                              fontSize: 12.0,
                              color: green,
                              font: fontFamily,
                            ),
                          ),
                        ),
                        pw.Align(
                          alignment: pw.Alignment.centerRight,
                          child: pw.Text(
                            // 'Address  : ${hospitalDetails['locality'] ?? ''}, ${hospitalDetails['city'] ?? ''}-${hospitalDetails['postalCode'] ?? ''},${hospitalDetails['state'] ?? ''}',
                            '${hospitalDetails['city'] ?? ''} - ${hospitalDetails['postalCode'] ?? ''},${hospitalDetails['state'] ?? ''}',
                            style: pw.TextStyle(
                              fontSize: 12.0,
                              color: green,
                              font: fontFamily,
                            ),
                          ),
                        ),
                        pw.Align(
                          alignment: pw.Alignment.centerRight,
                          child: pw.Text(
                            // 'Phone No.: ${hospitalDetails['phoneNumber'] ?? ''}, ${hospitalDetails['phoneTwo'] ?? ''}',
                            '${hospitalDetails['phoneNumber'] ?? ''}, ${hospitalDetails['phoneTwo'] ?? ''}',
                            style: pw.TextStyle(
                              fontSize: 12.0,
                              color: green,
                              font: fontFamily,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              pw.Divider(),
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                crossAxisAlignment: pw.CrossAxisAlignment.center,
                children: [
                  pw.Expanded(
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text(
                          'Patient Name: ${patientDetails['name'] ?? ''}',
                          // '${patientDetails['name'] ?? ''}',
                          style: pw.TextStyle(
                            fontSize: 12.0,
                            color: green,
                            font: fontFamily,
                          ),
                        ),
                        // pw.SizedBox(height: 3),

                        // pw.SizedBox(height: 3),
                        pw.Text(
                          'Phone No.: ${patientDetails['phone'] ?? ''}',
                          // '${patientDetails['phoneNumber'] ?? ''}',
                          style: pw.TextStyle(
                            fontSize: 12.0,
                            color: green,
                            font: fontFamily,
                          ),
                        ),
                        pw.Text(
                          'Date: ${DateFormat('dd/MM/yyyy').format(DateTime.now())}',
                          // ' ${DateFormat('dd/MM/yyyy').format(DateTime.now())}',
                          style: pw.TextStyle(
                            fontSize: 12.0,
                            color: green,
                            font: fontFamily,
                          ),
                        ),
                      ],
                    ),
                  ),
                  pw.Expanded(
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text(
                          'Age: ${patientDetails['age'] ?? ''}',
                          // '${patientDetails['age'] ?? ''}',
                          style: pw.TextStyle(
                            fontSize: 12.0,
                            color: green,
                            font: fontFamily,
                          ),
                        ),
                        pw.Text(
                          'Weight: ${patientDetails['weight'] ?? ''}',
                          // '${patientDetails['height'] ?? ''}',

                          style: pw.TextStyle(
                            fontSize: 12.0,
                            color: green,
                            font: fontFamily,
                          ),
                        ),
                        pw.Text(
                          'Height: ${patientDetails['height'] ?? ''}',
                          // ' ${patientDetails['weight'] ?? ''}',
                          style: pw.TextStyle(
                            fontSize: 12.0,
                            color: green,
                            font: fontFamily,
                          ),
                        ),
                      ],
                    ),
                  ),
                  // pw.SizedBox(width: 5),
                  pw.Expanded(
                    child: pw.Column(
                      crossAxisAlignment: pw.CrossAxisAlignment.start,
                      children: [
                        pw.Text(
                          'Gender: ${patientDetails['gender'] ?? ''}',
                          // '${patientDetails['gender'] ?? ''}',
                          style: pw.TextStyle(
                            fontSize: 12.0,
                            color: green,
                            font: fontFamily,
                          ),
                        ),
                        pw.Text(
                          'Blood Grp: ${patientDetails['bloodGroup'] ?? ''}',
                          // '${patientDetails['bloodGroup'] ?? ''}',
                          style: pw.TextStyle(
                            fontSize: 12.0,
                            color: green,
                            font: fontFamily,
                          ),
                        ),
                        // pw.Text(
                        //   'Token No.: ${index-1 ?? ''}',
                        //   // '${patientDetails['bloodGroup'] ?? ''}',
                        //   style: pw.TextStyle(
                        //     fontSize: 12.0,
                        //     color: green,
                        //     font: fontFamily,
                        //   ),
                        // ),
                      ],
                    ),
                  ),
                ],
              ),
              pw.Divider(),
              pw.SizedBox(height: 400), // Space for writing prescription
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Text(
                    'Signature',
                    style: pw.TextStyle(
                      fontSize: 16.0,
                      color: green,
                      font: fontFamily,
                    ),
                  ),
                  pw.Column(
                    children: [
                      pw.Container(
                        alignment: pw.Alignment.center,
                        child: pw.Text(
                          'For next Visit:',
                          style: pw.TextStyle(
                            fontSize: 13.0,
                            fontWeight: pw.FontWeight.bold,
                            color: green,
                            font: fontFamily,
                          ),
                        ),
                      ),
                      pw.Container(
                        alignment: pw.Alignment.center,
                        child: pw.Text(
                          'Date:_________  Time:________',
                          style: pw.TextStyle(
                            fontSize: 12.0,
                            fontWeight: pw.FontWeight.bold,
                            color: green,
                            font: fontFamily,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              pw.Divider(),
              pw.SizedBox(height: 20),
              pw.Row(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                children: [
                  pw.Row(
                    children: [
                      pw.Text(
                        'Powered by ClinicsQueue',
                        style: pw.TextStyle(
                          fontSize: 12.0,
                          color: green,
                          font: fontFamily,
                        ),
                      ),
                      pw.SizedBox(width: 5),
                      pw.Container(
                        alignment: pw.Alignment.center,
                        child: pw.Image(pw.MemoryImage(cqLogo),
                            height: 50, width: 50),
                      ),
                    ],
                  ),
                  // pw.SizedBox(width: 5),
                  pw.Column(children: [
                    pw.Text('Scan to install app'),
                    pw.SizedBox(height: 5),
                    pw.Image(qr, height: 80)
                  ])
                ],
              ),

              // pw.Container(
              //   alignment: pw.Alignment.center,
              //   child: pw.Image(pw.MemoryImage(cqLogo), height: 50, width: 50),
              // ),
              // pw.SizedBox(height: 10),
              // // show barcode of the url

              // pw.Container(
              //   alignment: pw.Alignment.center,
              //   child: pw.Text(
              //     'ClinicsQueue',
              //     style: pw.TextStyle(
              //       fontSize: 20.0,
              //       fontWeight: pw.FontWeight.bold,
              //       color: hospitalNameColor,
              //       font: fontFamily,
              //     ),
              //   ),
              // ),
            ],
          ),);
         
        },
      ),
    );

    return FileHandleApi.saveDocument(name: 'prescription.pdf', pdf: pdf);
  }
}
