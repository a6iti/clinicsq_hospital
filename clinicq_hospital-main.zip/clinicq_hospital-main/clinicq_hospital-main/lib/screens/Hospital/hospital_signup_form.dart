// ignore_for_file: use_build_context_synchronously

import 'dart:io';

import 'package:clincq_hospital/main.dart';
import 'package:clincq_hospital/screens/Hospital/hospital_login_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:uuid/uuid.dart';

class HospitalSignUpForm extends StatefulWidget {
  const HospitalSignUpForm({
    super.key,
  });

  @override
  State<HospitalSignUpForm> createState() => _HospitalSignUpFormState();
}

class _HospitalSignUpFormState extends State<HospitalSignUpForm> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _localityController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _phoneTwoController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();
  final TextEditingController _streetAddressController =
      TextEditingController();
  final TextEditingController _stateController = TextEditingController();
  final TextEditingController _postalCodeController = TextEditingController();
  final TextEditingController _landmarkController = TextEditingController();
  final TextEditingController _locationUrl = TextEditingController();
  String dropdownValue = 'Bhubaneswar';
  File? _imageFile; // To hold the selected image file

  // Method to pick an image from gallery
  Future<void> _pickImage() async {
    final pickedImage = await ImagePicker().pickImage(
      source: ImageSource.gallery,
    );
    if (pickedImage != null) {
      setState(() {
        _imageFile = File(pickedImage.path);
      });
    }
  }

  // Method to upload image to Firebase Storage
  Future<String?> _uploadImage() async {
    if (_imageFile == null) return null; // No image selected
    try {
      final storageRef = FirebaseStorage.instance
          .ref()
          .child('profile_images')
          .child('${_nameController.text}.jpg');
      await storageRef.putFile(_imageFile!);
      final imageUrl = await storageRef.getDownloadURL();
      return imageUrl;
    } catch (e) {
      // ignore: avoid_print
      print('Error uploading image: $e');
      return null;
    }
  }

  bool isValidEmail(String email) {
    // Regular expression for a simple email validation
    // This regex is basic and might not cover all valid email formats
    // You can replace it with a more comprehensive regex if needed
    String emailRegex = r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$';

    RegExp regExp = RegExp(emailRegex);

    return regExp.hasMatch(email);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _sizedBox(context),
            _header(),
            _sizedBox(context),
            _sizedBox(context),
            _textField(_nameController, 'Name', context, icon: Icons.person),
            _sizedBox(context),
            // drop down with 2 options - Cuttack and r
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: dropdownValue,
                  style: GoogleFonts.poppins(),
                  onChanged: (String? newValue) {
                    setState(() {
                      dropdownValue = newValue!;
                    });
                  },
                  items: <String>['Bhubaneswar', 'Cuttack']
                      .map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(
                        value,
                        style: GoogleFonts.poppins(
                          color: Colors.black,
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
            // _textField(_cityController, 'City', context,
            //     icon: Icons.location_city),
            _sizedBox(context),
            _textField(_localityController, 'Locality', context,
                icon: Icons.location_on),
            _sizedBox(context),
            _textField(
              _phoneNumberController,
              'Phone Number',
              context,
              icon: Icons.phone,
              isNumeric: true,
            ),
            _sizedBox(context),
            _textField(
              _phoneTwoController,
              'Alternate Phone Number',
              context,
              icon: Icons.phone,
              isNumeric: true,
            ),
            _sizedBox(context),
            _textField(_emailController, 'Email', context, icon: Icons.email),
            _sizedBox(context),
            _textField(_passwordController, 'Password', context,
                obscure: true, icon: Icons.password),
            _sizedBox(context),
            _textField(
              _confirmPasswordController,
              'Confirm Password',
              context,
              obscure: true,
              icon: Icons.password,
            ),
            _sizedBox(context),
            _textField(_streetAddressController, 'Address', context,
                icon: Icons.location_on),
            _sizedBox(context),
            _textField(_stateController, 'State', context,
                icon: Icons.location_on),
            _sizedBox(context),
            _textField(
              _postalCodeController,
              'Pin Code',
              context,
              icon: Icons.location_on,
              isNumeric: true,
            ),
            _sizedBox(context),
            _textField(_landmarkController, 'Landmark (Optional)', context,
                icon: Icons.location_on),
            _sizedBox(context),
            _imageFile != null
                ? Image.file(
                    _imageFile!,
                    height: 200,
                    width: 200,
                  )
                : Container(),
            _textField(_locationUrl, 'Location Url', context),
            _sizedBox(context),
            ElevatedButton(
              onPressed: _pickImage,
              child: const Text('Upload hospital logo'),
            ),
            _signUpButton(context),
            _login(context),
            _sizedBox(context),

            _sizedBox(context),
          ],
        ),
      ),
    );
  }

  Widget _header() {
    return Column(
      children: [
        SizedBox(
          height: MediaQuery.of(context).size.height * .02,
        ),
        const Text(
          'Sign up',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
        ),
        const Text(
          'Create your hospital account',
          style: TextStyle(fontSize: 16),
        ),
      ],
    );
  }

  Widget _textField(
    TextEditingController controller,
    String labelText,
    BuildContext context, {
    bool obscure = false,
    IconData? icon,
    bool isNumeric = false,
  }) {
    ValueNotifier<bool> obscureTextNotifier = ValueNotifier<bool>(obscure);
    return SizedBox(
      width: MediaQuery.of(context).size.width * .9,
      height: MediaQuery.of(context).size.height * .07,
      child: ValueListenableBuilder<bool>(
        valueListenable: obscureTextNotifier,
        builder: (context, value, child) {
          return TextField(
            controller: controller,
            style: GoogleFonts.poppins(),
            obscureText: value,
            keyboardType:
                (labelText == 'Phone Number' || labelText == 'Pin Code')
                    ? TextInputType.number
                    : TextInputType.text,
            inputFormatters: <TextInputFormatter>[
              isNumeric
                  ? FilteringTextInputFormatter.digitsOnly
                  : FilteringTextInputFormatter.singleLineFormatter,
            ],
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
              labelText: labelText,
              fillColor: Theme.of(context).colorScheme.primary.withOpacity(0.1),
              filled: true,
              prefixIcon: icon != null ? Icon(icon) : null,
              suffixIcon:
                  labelText == 'Password' || labelText == 'Confirm Password'
                      ? IconButton(
                          icon: Icon(
                            value ? Icons.visibility : Icons.visibility_off,
                          ),
                          onPressed: () {
                            obscureTextNotifier.value = !value;
                          },
                        )
                      : null,
            ),
          );
        },
      ),
    );
  }

  Widget _sizedBox(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * .02,
    );
  }

  Widget _signUpButton(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        maximumSize: const Size(double.infinity * .02, 50),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      onPressed: () async {
        if (_nameController.text.isEmpty ||
            _localityController.text.isEmpty ||
            _phoneNumberController.text.isEmpty ||
            _phoneTwoController.text.isEmpty ||
            _emailController.text.isEmpty ||
            _passwordController.text.isEmpty ||
            _confirmPasswordController.text.isEmpty ||
            _streetAddressController.text.isEmpty ||
            _stateController.text.isEmpty ||
            _postalCodeController.text.isEmpty ||
            _locationUrl.text.isEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Please fill all the fields'),
            ),
          );
          return;
        }
        if (_phoneNumberController.text.length != 10) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Please enter a valid phone number'),
            ),
          );
          return;
        }
        if (_phoneTwoController.text.length != 10) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Please enter a valid phone number'),
            ),
          );
          return;
        }
        if (!isValidEmail(_emailController.text.trim())) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Please enter a valid email'),
            ),
          );
          return;
        }
        //check email validation
        // if (!_emailController.text.contains('@') ||
        //     !_emailController.text.contains('.')) {
        //   ScaffoldMessenger.of(context).showSnackBar(
        //     const SnackBar(
        //       content: Text('Please enter a valid email'),
        //     ),
        //   );
        //   return;
        // }
        // if email is present in doctors collection then show error
        final docEmailCheck = await FirebaseFirestore.instance
            .collection('doctors')
            .where('email', isEqualTo: _emailController.text.trim())
            .get();
        if (docEmailCheck.docs.isNotEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                  'This email is already registered as a doctor. Please login with the same email or use another email to register as a hospital.'),
            ),
          );
          return;
        }
        // check if email is already registered
        final emailCheck = await FirebaseFirestore.instance
            .collection('hospitals')
            .where('email', isEqualTo: _emailController.text.trim())
            .get();
        // cheeck if email is present in authentication
        // final emailCheckAuth = await FirebaseAuth.instance
        //     .fetchSignInMethodsForEmail(_emailController.text.trim());
        // if (emailCheckAuth.isNotEmpty) {
        //   ScaffoldMessenger.of(context).showSnackBar(
        //     const SnackBar(
        //       content: Text('Email already registered, Please login'),
        //     ),
        //   );
        //   return;
        // }

        if (emailCheck.docs.isNotEmpty) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Email already registered, Please login'),
            ),
          );
          return;
        }
        if (_passwordController.text != _confirmPasswordController.text) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Passwords do not match'),
            ),
          );
        } else {
          showDialog(
            context: context,
            barrierDismissible: false,
            builder: (context) => const Center(
              child: CircularProgressIndicator(),
            ),
          );
          try {
            final imageUrl = await _uploadImage();
            await FirebaseAuth.instance.createUserWithEmailAndPassword(
              email: _emailController.text.trim(),
              password: _passwordController.text.trim(),
            );

            final uid = const Uuid().v4();

            await FirebaseFirestore.instance
                .collection('hospitals')
                .doc(uid)
                .set({
              'upiUrl': imageUrl == null
                  ? 'https://e7.pngegg.com/pngimages/364/960/png-clipart-health-care-health-text-logo-thumbnail.png'
                  : imageUrl,
              'email': _emailController.text.trim(),
              'name': _nameController.text,
              'city': dropdownValue,
              'locality': _localityController.text,
              'phoneNumber': _phoneNumberController.text,
              'phoneTwo': _phoneTwoController.text,
              'streetAddress': _streetAddressController.text,
              'state': _stateController.text,
              'postalCode': _postalCodeController.text,
              'landmark': _landmarkController.text,
              'locationUrl': _locationUrl.text,
              'uid': uid,
              'specialization': [],
              'doctors': [],
              'printCount': 0,
            });
          } catch (e) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(
                  e.toString(),
                ),
              ),
            );
          }
          navigatorKey.currentState!.popUntil((route) => route.isFirst);
        }
      },
      child: const Text('Sign Up',
          style: TextStyle(color: Colors.white, fontSize: 20)),
    );
  }
}

Widget _login(context) {
  final Color primaryColor = Theme.of(context).colorScheme.primary;

  return Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      const Text("Already have an account? "),
      TextButton(
        onPressed: () {
          Navigator.of(context).popAndPushNamed(
            HospitalLoginScreen.routeName,
          );
        },
        child: Text(
          "Login",
          style: TextStyle(color: primaryColor),
        ),
      ),
    ],
  );
}
