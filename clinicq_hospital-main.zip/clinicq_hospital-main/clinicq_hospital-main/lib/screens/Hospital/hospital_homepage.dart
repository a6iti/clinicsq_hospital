// ignore_for_file: avoid_print
import 'package:carousel_slider/carousel_slider.dart';

import 'package:clincq_hospital/screens/Hospital/Departments/department_home_screen.dart';
import 'package:clincq_hospital/screens/Hospital/Doctors/doctors_home_page.dart';
import 'package:clincq_hospital/screens/Hospital/profile_screen.dart';
import 'package:clincq_hospital/screens/Hospital/searchPatients.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

Future<String?> fetchHospitalName() async {
  try {
    // Assuming the collection name is 'hospitals' and each document represents a hospital
    QuerySnapshot querySnapshot =
        await FirebaseFirestore.instance.collection('hospitals').get();

    // Assuming there is only one hospital document, you can access its name
    if (querySnapshot.docs.isNotEmpty) {
      var hospitalName = querySnapshot.docs.first['name'];
      return hospitalName;
    } else {
      return null;
    }
  } catch (e) {
    print('Error fetching hospital name: $e');
    return null;
  }
}

Future<String?> fetchHospitalNamee(String userEmail) async {
  try {
    // Query Firestore to find the hospital associated with the user's email
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('hospitals')
        .where('email', isEqualTo: userEmail)
        .get();

    // If a hospital is found, return its name
    if (querySnapshot.docs.isNotEmpty) {
      var hospitalName = querySnapshot.docs.first['name'];
      return hospitalName;
    } else {
      return null;
    }
  } catch (e) {
    print('Error fetching hospital name: $e');
    return null;
  }
}

class HospitalHomepage extends StatefulWidget {
  const HospitalHomepage({
    super.key,
  });
  @override
  State<HospitalHomepage> createState() => _HospitalHomepageState();
}

class _HospitalHomepageState extends State<HospitalHomepage> {
  static const List<Widget> _pages = <Widget>[
    DepartmentHomeScreen(),
    DoctorsHomePage(),
    ProfileScreen(),
    // SearchPatientsPage(hospitalName: 'Hospital Name'),
  ];
  late Future<String?> _hospitalNameFuture = fetchHospitalName();

  static const List<String> _pageNames = <String>[
    'Departments',
    'Doctors',
    'Profile',
    'Patients'
  ];

  // static const List<Icon> _pageIcons = <Icon>[
  //   Icon(
  //     Icons.calendar_today_rounded,
  //     color: Color(0xffAD3306),
  //     size: 40,
  //   ),
  //   Icon(
  //     Icons.edit,
  //     color: Color(0xffAD3306),
  //     size: 40,
  //   ),
  //   Icon(
  //     Icons.person_rounded,
  //     color: Color(0xffAD3306),
  //     size: 40,
  //   ),
  // ];
  final CarouselController _caraoselController = CarouselController();
  int idx = 0;
  static const List<String> images = [
    "assets/img1.jpg",
    "assets/img2.jpg",
    "assets/img3.jpg"
  ];

  int _currentIndex = 0;
  // int _selectedIndex = 0;
  @override
  void initState() {
    super.initState();
    _hospitalNameFuture = fetchHospitalName();
  }

  // write a function to get the hospital name from the database

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final user = FirebaseAuth.instance.currentUser;

     // Check if the user is logged in
  if (user == null) {
    return const Scaffold(
      body: Center(
        child: Text(
          "Please log in first.",
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  final email = user.email; // Now it's safe to use

    return Scaffold(
      backgroundColor: const Color(0xFFF7E6DA),
      //add a background imag

      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.primary,
        automaticallyImplyLeading: false,
        title: FutureBuilder<String?>(
          future: _hospitalNameFuture,
          builder: (context, snapshot) {
            // if (snapshot.connectionState == ConnectionState.waiting) {
            //   return const Text('Welcome');
            // } else {
            //   if (snapshot.hasError || snapshot.data == null) {
            //     return const Text('Welcome');
            //   } else {
            return Center(
              child: Row(
                mainAxisAlignment: MainAxisAlignment
                    .center, // This will center the row contents
                children: [
                  Image.asset('assets/logo.png', height: height * 0.06),
                  const Text('ClinicsQueue',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold)),
                ],
              ),
            );
          },
        ),
      ),
      body: Padding(
        //add top padding to the GridView
        padding: EdgeInsets.only(
          top: MediaQuery.of(context).size.height * 0.00,
        ),
        child: Center(
          child: Column(
            children: [
              const SizedBox(
                height: 10,
              ),
              Stack(
                children: [
                  Container(
                    decoration: BoxDecoration(
                      color: const Color.fromARGB(255, 214, 213, 213),
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: const Color.fromARGB(255, 241, 239, 239)
                              .withOpacity(0.5),
                          spreadRadius: 2,
                          blurRadius: 5,
                          offset:
                              const Offset(0, 3), // changes position of shadow
                        ),
                      ],
                    ),
                    child: Column(
                      children: [
                        Container(
                          color: const Color(0xFFF7E6DA),
                          child: CarouselSlider(
                            items: images
                                .map((path) => Image.asset(
                                      path,
                                      fit: BoxFit.cover,
                                    ))
                                .toList(),
                            options: CarouselOptions(
                              height: 200,
                              viewportFraction: 1.0,
                              enlargeCenterPage: true,
                              autoPlay: true,
                              onPageChanged: (index, reason) {
                                setState(() {
                                  _currentIndex = index;
                                });
                              },
                            ),
                            carouselController: _caraoselController,
                          ),
                        ),
                        Container(
                          color: const Color(0xFFF7E6DA),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: images.map((path) {
                              int index = images.indexOf(path);
                              return Container(
                                width: 8.0,
                                height: 8.0,
                                margin: const EdgeInsets.symmetric(
                                    vertical: 10.0, horizontal: 2.0),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _currentIndex == index
                                      ? const Color(0xffAD3306)
                                      : Colors.grey,
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => _pages[0],
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      shape: const CircleBorder(),
                      padding: const EdgeInsets.all(0),
                    ),
                    child: CircleAvatar(
                      radius: 80,
                      backgroundColor: Colors.transparent,
                      // backgroundImage: AssetImage(images[0]),
                      child: Text(
                        _pageNames[0],
                        style: const TextStyle(color: Color(0xffAD3306)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 20),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => _pages[1],
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      shape: const CircleBorder(),
                      padding: const EdgeInsets.all(
                          0), // Ensure the button takes the size of the child
                    ),
                    child: CircleAvatar(
                      radius: 80,
                      backgroundColor: Colors.transparent,
                      // backgroundImage:
                      // AssetImage(images[1]), // Background image path
                      child: Text(
                        _pageNames[1],
                        style: const TextStyle(color: Color(0xffAD3306)),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => _pages[2],
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      shape: const CircleBorder(),
                      padding: const EdgeInsets.all(
                          0), // Ensure the button takes the size of the child
                    ),
                    child: CircleAvatar(
                      radius: 80,
                      backgroundColor: Colors.transparent,
                      // backgroundImage:
                      //     AssetImage(images[2]), // Background image path
                      child: Text(
                        _pageNames[2],
                        style: const TextStyle(
                          color: Color(0xffAD3306),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 20),
                  ElevatedButton(
                    onPressed: () async {
                      String? hospitalName = await fetchHospitalNamee(email!);

                      print(hospitalName);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              SearchPatientsPage(hospitalName: hospitalName!),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      shape: const CircleBorder(),
                      padding: const EdgeInsets.all(
                          0), // Ensure the button takes the size of the child
                    ),
                    child: CircleAvatar(
                      radius: 80,
                      backgroundColor: Colors.transparent,
                      // backgroundImage:
                      //     AssetImage(images[2]), // Background image path
                      child: Text(
                        _pageNames[3],
                        style: const TextStyle(
                          color: Color(0xffAD3306),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
