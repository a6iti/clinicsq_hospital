import 'dart:async';

import 'package:clincq_hospital/screens/Doctor/doctor_homepage.dart';
import 'package:clincq_hospital/screens/Doctor/profile_check_page.dart';
import 'package:clincq_hospital/screens/Hospital/Doctors/doctors_home_page.dart';
import 'package:clincq_hospital/screens/Hospital/hospital_homepage.dart';
import 'package:clincq_hospital/screens/homeScreen/home_screen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class MySplashScreen extends StatefulWidget {
  const MySplashScreen({super.key});

  @override
  State<MySplashScreen> createState() => _MySplashScreenState();
}

class _MySplashScreenState extends State<MySplashScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  bool isDoctor = false;
  String errorMessage = '';
  startTimer() {
    Timer(const Duration(seconds: 3), () async {
      // checkIfDoctor();

      //if user is loggedin already
      if (FirebaseAuth.instance.currentUser == null) {
        Navigator.push(
            context, MaterialPageRoute(builder: (C) => const MyHomePage()));
      }
      //if user is not logged in
      else {
        Future<bool> isUserPresent = isUserInCollection("doctors");
        if (await isUserPresent) {
          // User exists in the "users" collection

          Navigator.push(context,
              MaterialPageRoute(builder: (C) => const ProfileCheckPage()));
        } else {
          // User does not exist in the "users" collection
          Navigator.push(context,
              MaterialPageRoute(builder: (C) => const HospitalHomepage()));
        }

        // Navigator.push(
        //     context, MaterialPageRoute(builder: (C) => const AuthScreen()));
      }
    });
  }

  Future<bool> isUserInCollection(String collectionName) async {
    final user = FirebaseAuth.instance.currentUser; // Get current user

    // if (user == null) return false; // No user logged in

    final snapshot = await FirebaseFirestore.instance
        .collection(collectionName)
        .where("email", isEqualTo: user!.email)
        .get();

    return snapshot.docs.isNotEmpty; // Check if any documents match the query
  }

// Example usage:

// bool isUserPresent =  isUserInCollection("doctors");

// if (isUserPresent) {

//   // User exists in the "users" collection

// } else {

//   // User does not exist in the "users" collection

// }

  Future<void> checkIfDoctor() async {
    try {
      User? currentUser = _auth.currentUser;

      if (currentUser != null) {
        String uid = currentUser.uid;

        await FirebaseFirestore.instance
            .collection("doctors")
            .doc(currentUser.uid)
            .get()
            .then((snapshot) async {
          if (snapshot.exists) {
            Navigator.push(context,
                MaterialPageRoute(builder: (C) => const DoctorsHomePage()));
          } else {
            Navigator.push(context,
                MaterialPageRoute(builder: (C) => const HospitalHomepage()));
          }
        });

        // Query the "doctor" collection to check if the UID exists
        // DocumentSnapshot doctorSnapshot =
        //     await _firestore.collection('doctors').doc(uid).get();

        // setState(() {
        //   if (doctorSnapshot.exists) {
        //     isDoctor = true; // User is present in the doctor collection
        //     Navigator.push(context,
        //         MaterialPageRoute(builder: (C) => const DoctorsHomePage()));
        //   } else {
        //     isDoctor = false; // User is not in the doctor collection
        //     Navigator.push(context,
        //         MaterialPageRoute(builder: (C) => const HospitalHomepage()));
        //   }
        // });
      } else {
        setState(() {
          errorMessage = "No user logged in";
          Navigator.push(
              context, MaterialPageRoute(builder: (C) => const MyHomePage()));
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = e.toString();
      });
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    startTimer();
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Container(
        color: Colors.white,
        // decoration: const BoxDecoration(
        //     gradient: LinearGradient(
        //   colors: [Colors.amber, Colors.cyan],
        //   begin: FractionalOffset(0.0, 0.0),
        //   end: FractionalOffset(1.0, 0.0),
        //   stops: [0.0, 1.0],
        //   tileMode: TileMode.clamp,
        // )),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Image.asset("assets/logo.png"),
            ),
            const SizedBox(
              height: 10,
            ),
            // const Padding(
            //   padding: const EdgeInsets.all(18.0),
            //   child: Text(
            //     "Order food online with Hungers Doctor",
            //     textAlign: TextAlign.center,
            //     style: TextStyle(
            //       color: Colors.black54,
            //       fontSize: 20,
            //       fontFamily: "Train",
            //       letterSpacing: 3,
            //     ),
            //   ),
            // )
          ],
        ),
      ),
    );
  }
}
