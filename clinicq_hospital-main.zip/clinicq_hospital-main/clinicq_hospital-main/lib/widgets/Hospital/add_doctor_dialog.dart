// ignore_for_file: use_build_context_synchronously, unused_catch_clause

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

class AddDoctorDialog extends StatefulWidget {
  final List<Map<String, dynamic>> departmentList;
  final String hospitalId;
  final Map<String, String> hospitalDetails;

  const AddDoctorDialog({
    super.key,
    required this.departmentList,
    required this.hospitalId,
    required this.hospitalDetails,
  });

  @override
  // ignore: library_private_types_in_public_api
  _AddDoctorDialogState createState() => _AddDoctorDialogState();
}

class _AddDoctorDialogState extends State<AddDoctorDialog> {
  String? selectedDepartment;
  String selectedDepartmentId = '';
  final user = FirebaseAuth.instance.currentUser!;
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  // Email regex pattern
  @override
  void initState() {
    super.initState();
    if (widget.departmentList.isNotEmpty) {
      selectedDepartment = widget.departmentList[0]['name'] as String;
      selectedDepartmentId = widget.departmentList[0]['id'] as String;
    }
  }

  bool isValidEmail(String email) {
    // Regular expression for a simple email validation
    // This regex is basic and might not cover all valid email formats
    // You can replace it with a more comprehensive regex if needed
    String emailRegex = r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$';

    RegExp regExp = RegExp(emailRegex);

    return regExp.hasMatch(email);
  }

  @override
  Widget build(BuildContext context) {
    widget.departmentList.sort((a, b) => (a['name'] as String)
        .toLowerCase()
        .compareTo((b['name'] as String).toLowerCase()));
    return AlertDialog(
      title: const Text('Add new doctor'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Text(
            //   'Hospital: ${widget.hospitalDetails['name']}',
            //   style: const TextStyle(
            //     fontWeight: FontWeight.bold,
            //   ),
            // ),
            widget.departmentList.isEmpty
                ? const Column(
                    children: [
                      Text('There are no departments.',
                          style: TextStyle(color: Colors.red)),
                      SizedBox(height: 10),
                      Text(
                        'Please add a department first.',
                        style: TextStyle(color: Colors.red),
                      )
                    ],
                  )
                : DropdownButton<String>(
                    value: selectedDepartment,
                    onChanged: (String? newValue) {
                      setState(() {
                        selectedDepartment = newValue;
                      });
                    },
                    items: widget.departmentList.map<DropdownMenuItem<String>>(
                        (Map<String, dynamic> department) {
                      return DropdownMenuItem<String>(
                        value: department['name'] as String,
                        onTap: () {
                          selectedDepartmentId = department['id'] as String;
                        },
                        child: Text(department['name'] as String),
                      );
                    }).toList(),
                    // show department list in alphabetical order
                  ),
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Name',
              ),
            ),
            TextField(
              controller: emailController,
              decoration: const InputDecoration(
                labelText: 'Email',
              ),
            ),
            TextField(
              keyboardType: TextInputType.phone,
              controller: phoneController,
              decoration: const InputDecoration(
                labelText: 'Phone',
              ),
            ),
            TextField(
              controller: passwordController,
              decoration: const InputDecoration(
                labelText: 'Password',
              ),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () async {
            if (widget.departmentList.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Please add a department first'),
                ),
              );
              return;
            }
            if (nameController.text.isEmpty ||
                emailController.text.isEmpty ||
                phoneController.text.isEmpty ||
                passwordController.text.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Please fill all the fields'),
                ),
              );
              return;
            }
            if (phoneController.text.length != 10) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Please enter a valid phone number'),
                ),
              );
              return;
            }
            if (!isValidEmail(emailController.text)) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Please enter a valid email'),
                ),
              );
              return;
            }
            // check if email is already in use in doctors collection
            final emailExists = await FirebaseFirestore.instance
                .collection('doctors')
                .where('email', isEqualTo: emailController.text)
                .get();
            if (emailExists.docs.isNotEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Email already in use'),
                ),
              );
              return;
            }
            final uid = const Uuid().v4();
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (context) => const Center(
                child: CircularProgressIndicator(),
              ),
            );
            try {
              await FirebaseFirestore.instance
                  .collection('doctors')
                  .doc(uid)
                  .set({
                'id': uid,
                'name': nameController.text,
                'email': emailController.text,
                'phone': phoneController.text,
                'password': passwordController.text,
                'specialixationId': selectedDepartmentId,
                'hospitalId': widget.hospitalId,
                'profileAdded': false,
                'specialization': selectedDepartment,
                'profileVerified': false,
                'rating': 0,
                'slots': [],
                'hospitalName': widget.hospitalDetails['name'],
                'online': false
              });
              FirebaseApp app = await Firebase.initializeApp(
                name: 'Secondary',
                options: Firebase.app().options,
              );
              await FirebaseAuth.instanceFor(app: app)
                  .createUserWithEmailAndPassword(
                email: emailController.text,
                password: passwordController.text,
              );
              await app.delete();
              await FirebaseFirestore.instance
                  .collection('hospitals')
                  .doc(widget.hospitalId)
                  .update({
                'doctors': FieldValue.arrayUnion(
                  [
                    uid,
                  ],
                ),
              });
              await FirebaseFirestore.instance
                  .collection('departments')
                  .doc(selectedDepartmentId)
                  .update({
                'doctors': FieldValue.arrayUnion(
                  [
                    uid,
                  ],
                ),
              });
            } on FirebaseException catch (e) {
              // ScaffoldMessenger.of(context).showSnackBar(
              //   SnackBar(
              //     content: Text(e.message!),
              //   ),
              // );
            }
            Navigator.of(context).pop();
            Navigator.of(context).pop();
          },
          child: const Text('Add'),
        ),
      ],
    );
  }
}
