// ignore_for_file: use_build_context_synchronously

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppointmentCard extends StatefulWidget {
  const AppointmentCard({
    super.key,
    required this.patientName,
    required this.ticketNumber,
    required this.status,
    required this.slotIndex,
    required this.appointmentIndex,
    required this.appointmentId,
  });
  final String? patientName;
  final String? ticketNumber;
  final String? appointmentId;
  final bool? status;
  final int slotIndex;
  final int appointmentIndex;
  @override
  State<AppointmentCard> createState() => _AppointmentCardState();
}

class _AppointmentCardState extends State<AppointmentCard> {
  final user = FirebaseAuth.instance.currentUser!;
  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(widget.patientName.toString()),
      // subtitle: Text(widget.ticketNumber.toString()),
      trailing: widget.status == false
          ? Checkbox(
              value: widget.status,
              onChanged: (value) async {
                showDialog(
                  context: context,
                  barrierDismissible: false,
                  builder: (context) => const Center(
                    child: CircularProgressIndicator(),
                  ),
                );
                try {
                  final data = await FirebaseFirestore.instance
                      .collection('slots')
                      .doc(user.email)
                      .get();

                  await FirebaseFirestore.instance
                      .collection('appointments')
                      .doc(widget.appointmentId)
                      .update({
                    'status': value,
                  });

                  final slots = List.from(data['slots']);
                  final appointments =
                      List.from(slots[widget.slotIndex]['appointments']);
                  final appointment = Map<String, dynamic>.from(
                      appointments[widget.appointmentIndex]);
                  appointment['status'] = value;
                  appointments[widget.appointmentIndex] = appointment;
                  slots[widget.slotIndex]['appointments'] = appointments;

                  Map<String, dynamic> data2 =
                      Map<String, dynamic>.from(data.data()!);
                  data2['slots'] = slots;

                  await FirebaseFirestore.instance
                      .collection('slots')
                      .doc(user.email)
                      .set(data2);
                  Navigator.of(context).pop();
                  Navigator.of(context).pop();
                } on Exception catch (e) {
                  // ignore: avoid_print
                  print(e);
                  Navigator.of(context).pop();
                }
              },
            )
          : Text(
              'Already done',
              style: GoogleFonts.poppins(),
            ),
    );
  }
}
