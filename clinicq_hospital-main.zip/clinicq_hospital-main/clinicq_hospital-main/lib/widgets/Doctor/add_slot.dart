// ignore_for_file: use_build_context_synchronously, avoid_print

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';

class AddSlotDialog extends StatefulWidget {
  final String doctorId;
  final DateTime selectedDate;
  const AddSlotDialog({
    super.key,
    required this.doctorId,
    required this.selectedDate,
  });

  @override
  // ignore: library_private_types_in_public_api
  _AddSlotDialogState createState() => _AddSlotDialogState();
}

class _AddSlotDialogState extends State<AddSlotDialog> {
  String selectedDay = 'Monday';
  final TextEditingController _starttimeinput = TextEditingController();
  final TextEditingController _endtimeinput = TextEditingController();
  final TextEditingController _maxpatientinput = TextEditingController();
  final user = FirebaseAuth.instance.currentUser!;

  late DateTime selectedDate;

  @override
  void initState() {
    super.initState();
    selectedDate = widget.selectedDate;
  }

  int? _parseMaxPatients(String input) {
    try {
      return int.parse(input);
    } catch (e) {
      print("Error parsing max patients: $e");
      return null;
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime now = DateTime.now();
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: widget.selectedDate,
      firstDate: now,
      lastDate: DateTime(2101),
      selectableDayPredicate: (DateTime date) {
        return date.isAfter(now.subtract(const Duration(days: 1)));
      },
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  Future<void> _addSlotsForNext4Weeks() async {
    // Calculate dates for the next 4 weeks
    final List<DateTime> dates = [];
    for (int i = 0; i < 4; i++) {
      dates.add(selectedDate.add(Duration(days: i * 7)));
    }
    // Update slots for the next 4 weeks
    for (final DateTime date in dates) {
      _addSlot(date);
    }
  }

  bool showQueue = true;
  void _addSlot(DateTime date) async {
    final int? maxPatients = _parseMaxPatients(_maxpatientinput.text);
    if (maxPatients == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Please enter a valid number for max patients"),
        ),
      );
      return;
    }

    final formattedDate = DateFormat('yyyy-MM-dd').format(date);

    try {
      final uid = const Uuid().v4();
      await FirebaseFirestore.instance.collection('slots').doc(uid).set({
        'date': formattedDate, // Use the formatted date
        'starttime': _starttimeinput.text,
        'endtime': _endtimeinput.text,
        'maxpatient': maxPatients,
        'appointments': [],
        'id': uid,
        'showQueue': showQueue,
        'doctorId': widget.doctorId,
      });
      await FirebaseFirestore.instance
          .collection('doctors')
          .doc(widget.doctorId)
          .update({
        'slots': FieldValue.arrayUnion(
          [
            uid,
          ],
        ),
      });
    } catch (e) {
      throw Exception("Failed to add slot: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Add new slot'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Date Picker
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text("${widget.selectedDate.toLocal()}".split(' ')[0]),
                const SizedBox(
                  height: 20.0,
                ),
                ElevatedButton(
                  onPressed: () => _selectDate(context),
                  child: const Text('Select date'),
                ),
              ],
            ),
            TextField(
              controller: _starttimeinput,
              decoration: const InputDecoration(
                labelText: 'Start Time',
              ),
              readOnly:
                  true, //set it true, so that user will not able to edit text
              onTap: () async {
                TimeOfDay? pickedTime = await showTimePicker(
                  initialTime: TimeOfDay.now(),
                  context: context,
                );

                if (pickedTime != null) {
                  final now = DateTime.now();
                  final pickedDateTime = DateTime(
                    now.year,
                    now.month,
                    now.day,
                    pickedTime.hour,
                    pickedTime.minute,
                  );
                  final formattedTime =
                      DateFormat('HH:mm:ss').format(pickedDateTime);

                  setState(() {
                    _starttimeinput.text = formattedTime;
                  });
                } else {
                  print("Time is not selected");
                }
              },
            ),
            TextField(
              controller: _endtimeinput,
              decoration: const InputDecoration(
                labelText: 'End Time',
              ),
              readOnly:
                  true, //set it true, so that user will not able to edit text
              onTap: () async {
                TimeOfDay? pickedTime = await showTimePicker(
                  initialTime: TimeOfDay.now(),
                  context: context,
                );

                if (pickedTime != null) {
                  final now = DateTime.now();
                  final pickedDateTime = DateTime(
                    now.year,
                    now.month,
                    now.day,
                    pickedTime.hour,
                    pickedTime.minute,
                  );
                  final formattedTime =
                      DateFormat('HH:mm:ss').format(pickedDateTime);

                  setState(() {
                    _endtimeinput.text = formattedTime;
                  });
                } else {
                  print("Time is not selected");
                }
              },
            ),
            TextField(
              controller: _maxpatientinput,
              decoration: const InputDecoration(
                labelText: 'Max Patient',
              ),
              keyboardType: TextInputType.number,
              inputFormatters: <TextInputFormatter>[
                FilteringTextInputFormatter.digitsOnly
              ],
            ),
            SizedBox(
              height: 10,
            ),
            //create a show queue on or off button
            Row(
              children: [
                Text('Show Queue'),
                SizedBox(
                  width: 10,
                ),
                Switch(
                  activeColor: Colors.green,
                  value: showQueue,
                  onChanged: (value) {
                    setState(() {
                      showQueue = value;
                    });
                    // print(showQueue.toString());
                  },
                ),
              ],
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: const Text('Cancel'),
        ),
        TextButton(
          onPressed: () async {
            final format = DateFormat("HH:mm");
            DateTime startTime = format.parse(_starttimeinput.text);
            DateTime endTime = format.parse(_endtimeinput.text);

            DateTime startTimeWithoutSeconds = DateTime(
                startTime.year,
                startTime.month,
                startTime.day,
                startTime.hour,
                startTime.minute);
            DateTime endTimeWithoutSeconds = DateTime(endTime.year,
                endTime.month, endTime.day, endTime.hour, endTime.minute);

            if (endTimeWithoutSeconds.isBefore(startTimeWithoutSeconds) ||
                endTimeWithoutSeconds
                    .isAtSameMomentAs(startTimeWithoutSeconds)) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('End time should be greater than start time'),
                ),
              );
              return;
            }

            // add it to firebase
            showDialog(
              context: context,
              barrierDismissible: false,
              builder: (context) => const Center(
                child: CircularProgressIndicator(),
              ),
            );
            try {
              // Add slots for the next 4 weeks
              await _addSlotsForNext4Weeks();
              // show success message
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Slot added successfully'),
                ),
              );
              Navigator.of(context).pop();
              Navigator.of(context).pop(); // Pop twice to close both dialogs
            } catch (e) {
              Navigator.of(context).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(e.toString()),
                ),
              );
            }
          },
          child: const Text('Add'),
        ),
      ],
    );
  }
}
