import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class HospitalAuth with ChangeNotifier {
  var hospitalRef = FirebaseFirestore.instance.collection('hospitals');
  final authUser = FirebaseAuth.instance.currentUser!;
  Future<String> fetchHospitalId(String email) async {
    final hospitalId = await hospitalRef
        .where(
          'email',
          isEqualTo: email,
        )
        .get()
        .then((value) => value.docs[0].id);
    return hospitalId;
  }
}
