import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class DoctorAuth with ChangeNotifier {
  final authUser = FirebaseAuth.instance.currentUser!;
  var hospitalRef = FirebaseFirestore.instance.collection('doctors');
  Future<String> fetchDoctorId(String s) async {
    final doctorId = await hospitalRef
        .where('email', isEqualTo: authUser.email)
        .get()
        .then((value) => value.docs[0].id);
    return doctorId;
  }
}