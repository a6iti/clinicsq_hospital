package com.example.clincq_hospital

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
