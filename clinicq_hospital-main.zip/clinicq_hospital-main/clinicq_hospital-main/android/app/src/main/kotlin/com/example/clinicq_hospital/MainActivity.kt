package com.example.clinicq_hospital

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
